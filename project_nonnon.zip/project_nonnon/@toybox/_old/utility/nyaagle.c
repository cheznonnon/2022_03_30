// Nonnon Text Search
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




//#include "../../../nonnon/project/define_unicode.c"




// the base layer

#include "../../../nonnon/neutral/path.c"
#include "../../../nonnon/neutral/txt.c"

#include "../../../nonnon/win32/ole/IDropTarget.c"
#include "../../../nonnon/win32/win.c"
#include "../../../nonnon/win32/win_txtbox.c"

#include "../../../nonnon/project/macro.c"




// rc.h

#define H_QUERY    nyaagle.hgui[ 0 ]
#define H_BUTTON   nyaagle.hgui[ 1 ]
#define H_TXTBOX   nyaagle.hgui[ 2 ]
#define GUI_MAX                  3


#define APPNAME    "Nyaagle"




typedef struct {

	HWND         hgui[ GUI_MAX ];
	n_win_txtbox txtbox;

	s32          minwsx,minwsy;

	WNDPROC      pfunc;

} n_nyaagle;


static n_nyaagle nyaagle;




bool
n_nyaagle_file( n_posix_char *name, n_posix_char *query )
{

	if ( false == n_posix_stat_is_file( name ) ) { return true; }


	n_txt txt; n_txt_zero( &txt );

	if ( n_txt_load( &txt, name ) ) { return true; }


	if ( n_string_search_simple( txt.stream, query ) )
	{
		n_win_txtbox_line_add( &nyaagle.txtbox, 0, name );
	}


	n_txt_free( &txt );


	return false;
}

bool
n_nyaagle_directory( n_posix_char *name, n_posix_char *query )
{

	if ( false == n_nyaagle_file( name, query ) ) { return false; }

	if ( false == n_posix_stat_is_dir( name ) ) { return true; }


	n_posix_DIR *dp = n_posix_opendir_nodot( name );
	if ( dp == NULL ) { return true; }

	while( 1 )
	{

		n_posix_dirent *dirent = n_posix_readdir( dp );
		if ( dirent == NULL ) { break; }


		n_posix_char abspath[ N_PATH_MAX ];
		n_path_maker( name, dirent->d_name, abspath );


		if ( n_posix_stat_is_dir( abspath ) )
		{
			n_nyaagle_directory( abspath, query );
		} else {
			n_nyaagle_file( abspath, query );
		}

	}

	n_posix_closedir( dp );


	return false;
}

// internal
void
n_nyaagle_resize( HWND hwnd )
{

	const bool redraw = true;


	s32 ctl,ico,m;
	n_win_stdsize( hwnd, &ctl, &ico, &m );


	s32 csy = ( ctl * 1 ) + ( ctl * 4 );
	s32 csx = (double) csy * sqrt( 2 );

	csx = n_posix_max_s32( 320, csx );
	csy = n_posix_max_s32( 240, csy );

	nyaagle.minwsx = csx + m;
	nyaagle.minwsy = csy + m;


	n_win w;

	{

		static bool is_first = true;


		if ( is_first )
		{

			is_first = false;

			n_win_set( hwnd, &w, csx + m, csy + m, N_WIN_SET_CENTERING );

		} else {

			n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		}

	}


	csx = w.csx - m;
	csy = w.csy - m;


	s32  list_sy = csy - ( ctl * 1 );
	s32   btn_sx = ( ico * 2 );
	s32 query_sx = csx - btn_sx;


	n_win_move( nyaagle.txtbox.hwnd, 0, ctl,      csx, list_sy, redraw );
	n_win_move( H_QUERY,             0,   0, query_sx,     ctl, redraw );
	n_win_move( H_BUTTON,     query_sx,   0,   btn_sx,     ctl, redraw );


	return;
}

// internal
LRESULT CALLBACK
n_nyaagle_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{
		n_win_message_send( GetParent( hwnd ), WM_COMMAND, 0, H_BUTTON );
		return true;
	}


	return false;
}

LRESULT CALLBACK
n_nyaagle_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char cmdline[ N_PATH_MAX ];


	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_win_stdfont_init( nyaagle.hgui, GUI_MAX );
		n_nyaagle_resize( hwnd );

	break;


	case WM_CREATE :


		// Global

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_init( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		n_win_ime_disable( hwnd );

		n_memory_zero( &nyaagle, sizeof( n_nyaagle ) );


		// Window

		n_win_init_literal( hwnd, APPNAME, "", "" );

		n_win_gui_literal( hwnd, N_INPUT, "", &H_QUERY  );
		n_win_gui_literal( hwnd, FBTN   , "", &H_BUTTON );

		n_win_text_set( H_BUTTON, n_project_string_go );

		n_win_txtbox_zero( &nyaagle.txtbox );
		n_win_txtbox_init( &nyaagle.txtbox, hwnd, N_WIN_TXTBOX_STYLE_LISTBOX | N_WIN_TXTBOX_STYLE_VSCROLL, 0 );
		H_TXTBOX = nyaagle.txtbox.hwnd;


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_exstyle_add( H_QUERY, WS_EX_CLIENTEDGE );
		n_win_property_init_literal( H_QUERY, "WM_KEYDOWN", (int) n_nyaagle_on_keydown );


		// Size

		n_win_stdfont_init( nyaagle.hgui, GUI_MAX );
		n_nyaagle_resize( hwnd );


		// Init

		n_win_commandline( cmdline );

		// Needed : for Watchcat
		//n_string_commandline_option_literal( "-nyaagle", cmdline );

		n_win_hwndprintf_literal( hwnd, "%s %s", APPNAME, cmdline );


		// Display

		SetFocus( H_QUERY );

		ShowWindow( hwnd, SW_NORMAL );

	break;

	case WM_SIZE :

		n_nyaagle_resize( hwnd );

	break;

	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_win_hwndprintf_literal( hwnd, "%s %s", APPNAME, cmdline );

		SetFocus( H_QUERY );

	break;

	case WM_COMMAND :
	{

		HWND h = (HWND) lparam;


		if ( h == nyaagle.txtbox.hwnd )
		{

			if ( wparam == WM_LBUTTONDBLCLK )
			{
				n_posix_char name[ N_PATH_MAX ];
				n_win_txtbox_selection_get( &nyaagle.txtbox, name );
				ShellExecute( hwnd, NULL, name, NULL, NULL, SW_SHOWNORMAL );
			}

		} else

		if ( h == H_BUTTON )
		{

			n_posix_char query[ N_PATH_MAX ]; n_win_text_get( H_QUERY, query, N_PATH_MAX - 1 );


			n_project_pleasewait_on( hwnd );

			n_nyaagle_directory( cmdline, query );
			n_win_txtbox_refresh( &nyaagle.txtbox );

			n_project_pleasewait_off( hwnd );

		}


	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_exit( nyaagle.hgui, GUI_MAX );

		n_win_txtbox_exit( &nyaagle.txtbox );

		n_win_property_exit_literal( H_QUERY, "WM_KEYDOWN" );

#ifdef _H_NONNON_WIN32_OLE_IDROPTARGET
		n_IDropTarget_exit( hwnd );
#endif // _H_NONNON_WIN32_OLE_IDROPTARGET

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_txtbox_proc( hwnd, msg, wparam, lparam, &nyaagle.txtbox );

	n_win_minsize_proc( hwnd, msg, wparam, lparam, nyaagle.minwsx,nyaagle.minwsy );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE hprv, LPSTR cmd, int show )
{
	return n_win_main( NULL, n_nyaagle_wndproc );
}


