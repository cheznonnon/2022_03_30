



#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




void
n_win_alphablend( HWND hwnd, u8 alpha )
{

	// LWA_COLORKEY	0x01
	// LWA_ALPHA	0x02

	// alpha
	//	  0 : transparent
	//	255 : non-transparent


	const int lwa_alpha = 2;


	HMODULE hmod;
	FARPROC func;


	hmod = LoadLibrary( n_posix_literal( "user32.dll" ) );
	if ( hmod == NULL ) { return; }


	func = GetProcAddress( hmod, "SetLayeredWindowAttributes" );
	if ( func == NULL )
	{
		FreeLibrary( hmod );

		return;
	}


	n_win_exstyle_add( hwnd, WS_EX_LAYERED );

	(*func)( hwnd, 0, alpha, lwa_alpha );


	FreeLibrary( hmod );


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon Effect Catalog", "", "" );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_style_dropshadow_onoff( hwnd, n_true );


		// Size

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		// [!] : before ShowWindow()

		n_win_animatewindow( hwnd, 0, n_AW_ACTIVATE | n_AW_BLEND );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :

		n_win_animatewindow( hwnd, 1000, n_AW_HIDE     | n_AW_BLEND );
		n_win_animatewindow( hwnd, 1000, n_AW_ACTIVATE | n_AW_BLEND );

	break;

	case WM_MBUTTONDOWN :

		n_win_animatewindow( hwnd, 1000, n_AW_HIDE     | n_AW_SLIDE | n_AW_HOR_POSITIVE );
		n_win_animatewindow( hwnd, 1000, n_AW_ACTIVATE | n_AW_SLIDE | n_AW_HOR_NEGATIVE );

	break;

	case WM_RBUTTONDOWN :

		n_win_animatewindow( hwnd, 1000, n_AW_HIDE     | n_AW_CENTER );
		n_win_animatewindow( hwnd, 1000, n_AW_ACTIVATE | n_AW_CENTER );

	break;


	case WM_KEYDOWN :
	{

		static int alpha = 255;


		if ( wparam == VK_UP )
		{
			alpha++;
			if ( alpha >= 255 ) { alpha = 255; }
		} else

		if ( wparam == VK_DOWN )
		{
			alpha--;
			if ( alpha <=   0 ) { alpha =   0; }
		}// else

		n_win_alphablend( hwnd, alpha );


		{
			char str[ 100 ];

			sprintf( str, "Alpha : %d", alpha );

			SetWindowText( hwnd, str );
		}

	}
	break;

	case WM_KEYUP :

		SetWindowText( hwnd, "Nonnon Effect Catalog" );

	break;


	case WM_CLOSE :

		n_win_animatewindow( hwnd, 0, n_AW_HIDE | n_AW_BLEND );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

