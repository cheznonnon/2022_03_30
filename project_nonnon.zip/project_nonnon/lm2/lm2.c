// LINE MASHER 2
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"

#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"
#include "../nonnon/game/rc.c"
#include "../nonnon/game/sound.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/neutral/wav/all.c"

#include "../nonnon/project/macro.c"




static double n_lm2_chara_draw_blend = 0.0;

inline void
n_lm2_chara_draw( n_game_chara *c )
{

	n_game_chara_prv( c );


	n_type_gfx fx  = c->srcx;
	n_type_gfx fy  = c->srcy;
	n_type_gfx fsx = c->sx;
	n_type_gfx fsy = c->sy;
	n_type_gfx tx  = c->x;
	n_type_gfx ty  = c->y;

	if ( c->mx ) { fx += c->mx; fsx -= c->mx * 2; tx += c->mx; }
	if ( c->my ) { fy += c->my; fsy -= c->my * 2; ty += c->my; }

	n_bmp_blendcopy( c->chara, c->main, fx,fy,fsx,fsy, tx,ty, n_lm2_chara_draw_blend );


	return;
}





// Constants

#define LM2_WAV_M            "N_PROJECT_SOUND_MUTE"
#define LM2_WAV_0            "N_PROJECT_SOUND_BWOPP"
#define LM2_WAV_2            "N_PROJECT_SOUND_CLICK"
#define LM2_WAV_3            "N_PROJECT_SOUND_WOOW"


#define N_LM2_CHARA_INDEX    ( 0 )
#define N_LM2_MSG_1_INDEX    ( 1 )
#define N_LM2_MSG_2_INDEX    ( 2 )
#define N_LM2_BMPBG_INDEX    ( 3 )
#define N_LM2_DGT_1_INDEX    ( 4 )
#define N_LM2_DGT_2_INDEX    ( 5 )
#define N_LM2_STARS_INDEX    ( 6 )
#define N_LM2_BMP_ALL        ( 7 )

#define N_LM2_BWOPP_INDEX    ( 0 )
#define N_LM2_SHOOT_INDEX    ( 1 )
#define N_LM2_CHIPP_INDEX    ( 2 )
#define N_LM2_WOOOW_INDEX    ( 3 )
#define N_LM2_PHOOT_INDEX    ( 4 )
#define N_LM2_SND_ALL        ( 5 )

#define N_LM2_CHARA_FIRE_MIN (    3 )
#define N_LM2_CHARA_FIRE_MAX (  255 )
#define N_LM2_CHARA_FIRE_RND ( 1500 )
#define N_LM2_VIRUS_FIRE_RND ( 2500 )
#define N_LM2_VIRUS_SX       (   18 )
#define N_LM2_VIRUS_SY       (    3 )
#define N_LM2_VIRUS_MAX      ( N_LM2_VIRUS_SX * N_LM2_VIRUS_SY )


#define N_LM2_FIRE_OFF            0
#define N_LM2_FIRE_ON_SLOW        1
#define N_LM2_FIRE_ON_FAST        2
#define N_LM2_FIRE_ON_TRICKY_SLOW 3
#define N_LM2_FIRE_ON_TRICKY_FAST 4

#define N_LM2_FIRE_ON        N_LM2_FIRE_ON_SLOW
#define N_LM2_FIRE_ON_DOUBLE N_LM2_FIRE_ON_TRICKY_SLOW

#define N_LM2_VIRUS_STOP     0
#define N_LM2_VIRUS_FIRE     1
#define N_LM2_VIRUS_DEAD     2


#define N_LM2_STARS_MAX       ( 50 )

#define N_LM2_STARS_SLOW      (  0 )
#define N_LM2_STARS_FAST      (  1 )
#define N_LM2_STARS_RAND      (  5 )


#define N_LM2_POWER_NONE     ( 0 )
#define N_LM2_POWER_LASER_1  ( 1 )
#define N_LM2_POWER_LASER_2  ( 2 )
#define N_LM2_POWER_GATLING  ( 3 )
#define N_LM2_POWER_STARDUST ( 4 )
#define N_LM2_POWER_SHIELD   ( 5 )

#define n_lm2_power_laser_1(  p ) ( ( (p)->level >=   5 )&&( (p)->power < N_LM2_POWER_LASER_1  ) )
#define n_lm2_power_laser_2(  p ) ( ( (p)->level >=  10 )&&( (p)->power < N_LM2_POWER_LASER_2  ) )
#define n_lm2_power_gatling(  p ) ( ( (p)->level >=  25 )&&( (p)->power < N_LM2_POWER_GATLING  ) )
#define n_lm2_power_stardust( p ) ( ( (p)->level >=  50 )&&( (p)->power < N_LM2_POWER_STARDUST ) )
#define n_lm2_power_shield(   p ) ( ( (p)->level >= 100 )&&( (p)->power < N_LM2_POWER_SHIELD   ) )


#define N_LM2_TRANSITION_NONE     ( 0 )
#define N_LM2_TRANSITION_FADE_IN  ( 1 )
#define N_LM2_TRANSITION_FADE_OUT ( 2 )



typedef struct {

	n_type_gfx   zoom;
	n_type_gfx   csx,csy;
	n_type_gfx   unit;
	n_type_gfx   min_x, mid_x, max_x;
	n_type_gfx   msg1_x, msg2_x;
	n_type_gfx   hit_offset_x,hit_offset_y;

	n_type_gfx   star_size;

	n_type_gfx   step_chara;
	n_type_gfx   step_chara_fire;
	n_type_gfx   step_virus_slow;
	n_type_gfx   step_virus_fast;

	n_gdi        gdi;
	n_bmp        bmp[ N_LM2_BMP_ALL ];
	n_game_sound snd[ N_LM2_SND_ALL ];
	n_game_sound snd_mute;

	n_game_input input;

	n_game_chara item;
	n_game_chara chara;
	n_game_chara virus     [ N_LM2_VIRUS_MAX      ];
	n_game_chara chara_fire[ N_LM2_CHARA_FIRE_MAX ];
	n_game_chara virus_fire[ N_LM2_VIRUS_MAX      ];
	double       gatling   [ N_LM2_CHARA_FIRE_MAX ];

	n_game_chara stars     [ N_LM2_STARS_MAX      ];
	u32          stars_tmr [ N_LM2_STARS_MAX      ];

	int          chara_fire_min;
	int          chara_fire_max;
	int          chara_fire_rnd;
	int          chara_fire_cur;
	int          chara_fire_tmr;

	int          virus_sx;
	int          virus_sy;
	int          virus_max;
	int          virus_fire_rnd;
	int          virus_fire_tmr;
	int          virus_fire_level;

	n_bool       reset;
	u32          reset_timer;
	int          hiscore, score, score_counter;
	int          hiscore_prev, score_prev;
	int          level, power;

	n_bool       delayed_margin_onoff;

	double       transition_phase;

	n_bool       debug_invincible;

} n_lm2;


static n_lm2 lm2;




// Component

#include "./lm2_effect.c"




#define n_lm2_zero( p ) n_memory_zero( p, sizeof( n_lm2 ) )

#define n_lm2_vibrate_off( p ) n_lm2_vibrate( p, n_false )
#define n_lm2_vibrate_on(  p ) n_lm2_vibrate( p, n_true  )

void
n_lm2_vibrate( n_lm2 *p, n_bool is_on )
{

	int v;
	if ( is_on )
	{
		v = N_GAME_INPUT_XINPUT_VIBRATE_MAX;
	} else {
		v = 0;
	}

	n_game_input_XInput_vibrate( &p->input, v, v );


	return;
}

void
n_lm2_sound( n_lm2 *p, int index )
{

	n_game_sound *s = &p->snd[ index ];

	n_game_sound_loop( s );


	return;
}

void
n_lm2_gradient_refresh( n_lm2 *p, u32 upper, u32 lower )
{
//u32 tick = n_posix_tickcount();


	// [!] : 2 msec @ 1500MHz

	n_bmp_new_fast( &p->bmp[ N_LM2_BMPBG_INDEX ], p->csx, p->csy );

	if ( upper == lower )
	{
		n_bmp_flush( &p->bmp[ N_LM2_BMPBG_INDEX ], upper );
		return;
	}


	// [!] : Performance : CPU @ 1500MHz
	//
	//	1/1 : 200 msec
	//	1/2 :  70 msec
	//	1/3 :  50 msec

	int option = N_BMP_GRADIENT_RECTANGLE | N_BMP_GRADIENT_VERTICAL;

	n_type_gfx sy = p->csy / 3;
	n_bmp_gradient
	(
		&p->bmp[ N_LM2_BMPBG_INDEX ],
		0, p->csy - sy, p->csx, sy,
		upper, lower, option
	);


//n_game_hwndprintf_literal( "%d", (int) n_posix_tickcount() - tick );
	return;
}

void
n_lm2_digitbitmap( n_lm2 *p )
{

	// Hiscore

	if ( p->hiscore_prev != p->hiscore )
	{
//static int z = 0;n_game_hwndprintf_literal( "%d", z );z++;

		p->hiscore_prev = p->hiscore;

		n_posix_char str[ 10 ];

		p->gdi.sx   = 0;
		p->gdi.text = str;

		n_posix_sprintf_literal( str, "% 5d", p->hiscore );

		n_gdi_bmp( &p->gdi, &p->bmp[ N_LM2_DGT_1_INDEX ] );

	}

	{

		n_bmp      *b = &p->bmp[ N_LM2_MSG_1_INDEX ];
		n_type_gfx  x = p->msg1_x;
		n_type_gfx  y = 0;
		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );

		n_bmp_blendcopy( b, &game.bmp, 0,0,sx,sy, x,y, n_lm2_chara_draw_blend );

	}

	{

		n_bmp      *b = &p->bmp[ N_LM2_DGT_1_INDEX ];
		n_type_gfx  x = p->msg1_x + p->unit;
		n_type_gfx  y = 0;
		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );

		n_bmp_blendcopy( b, &game.bmp, 0,0,sx,sy, x,y, n_lm2_chara_draw_blend );

	}


	// Score

	if ( p->score_prev != p->score )
	{

		p->score_prev = p->score;

		n_posix_char str[ 10 ];

		p->gdi.sx   = 0;
		p->gdi.text = str;

		n_posix_sprintf_literal( str, "%d", p->score );

		n_gdi_bmp( &p->gdi, &p->bmp[ N_LM2_DGT_2_INDEX ] );

	}

	{

		n_bmp      *b = &p->bmp[ N_LM2_MSG_2_INDEX ];
		n_type_gfx  x = p->msg2_x - N_BMP_SX( &p->bmp[ N_LM2_DGT_2_INDEX ] );
		n_type_gfx  y = 0;
		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );

		n_bmp_blendcopy( b, &game.bmp, 0,0,sx,sy, x,y, n_lm2_chara_draw_blend );

	}

	{

		n_bmp      *b = &p->bmp[ N_LM2_DGT_2_INDEX ];
		n_type_gfx  x = p->msg2_x - N_BMP_SX( &p->bmp[ N_LM2_DGT_2_INDEX ] ) + p->unit;
		n_type_gfx  y = 0;
		n_type_gfx sx = N_BMP_SX( b );
		n_type_gfx sy = N_BMP_SY( b );

		n_bmp_blendcopy( b, &game.bmp, 0,0,sx,sy, x,y, n_lm2_chara_draw_blend );

	}


	return;
}

void
n_lm2_reset( n_lm2 *p )
{

	n_bmp *bmp_bg    = &p->bmp[ N_LM2_BMPBG_INDEX ];
	n_bmp *bmp_chara = &p->bmp[ N_LM2_CHARA_INDEX ];

	n_type_gfx u = p->unit;


	n_game_chara_zero( &p->chara );
	n_game_chara_zero( &p->item  );

	n_game_chara_bmp( &p->chara, &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bmp( &p->item,  &game.bmp, bmp_chara, bmp_bg, game.color );

	n_game_chara_src( &p->chara, u * 0,u * 0, u,u, 0,0 );
	n_game_chara_src( &p->item,  u * 0,u * 3, u,u, p->zoom * 3,p->zoom * 3 );

	n_game_chara_pos( &p->chara, p->mid_x, game.sy - p->unit );
	n_game_chara_pos( &p->item,  p->mid_x,         - p->unit );

	n_game_chara_prv( &p->chara );
	n_game_chara_prv( &p->item  );


	n_game_chara_bulk_zero( p->chara_fire, p->chara_fire_max );
	n_game_chara_bulk_zero( p->virus_fire, p->virus_max      );
	n_game_chara_bulk_zero( p->virus,      p->virus_max      );

	n_game_chara_bulk_bmp( p->chara_fire, p->chara_fire_max, &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bulk_bmp( p->virus     , p->virus_max,      &game.bmp, bmp_chara, bmp_bg, game.color );
	n_game_chara_bulk_bmp( p->virus_fire, p->virus_max,      &game.bmp, bmp_chara, bmp_bg, game.color );

	n_game_chara_bulk_src( p->chara_fire, p->chara_fire_max, u * 0,u * 2, u,u, p->zoom * 6,p->zoom * 2 );
	n_game_chara_bulk_src( p->virus     , p->virus_max,      u * 0,u * 1, u,u, p->zoom * 1,p->zoom * 1 );
	n_game_chara_bulk_src( p->virus_fire, p->virus_max,      u * 3,u * 1, u,u, p->zoom * 3,p->zoom * 3 );


	int i = 0;
	while( 1 )
	{

		int x = ( i % p->virus_sx ) * u;
		int y = ( i / p->virus_sx ) * u;

		n_game_chara_pos( &p->virus[ i ], u + x, u + y );
		n_game_chara_prv( &p->virus[ i ] );

		n_game_chara_pos( &p->virus_fire[ i ], -u, -u );
		n_game_chara_prv( &p->virus_fire[ i ] );


		i++;
		if ( i >= p->virus_max ) { break; }
	}


	p->hiscore_prev   = -1;
	p->score_prev     = -1;
	p->score          = 0;
	p->score_counter  = 0;
	p->level          = p->score / 100;
	p->power          = N_LM2_POWER_NONE;

	p->chara_fire_cur = p->chara_fire_min;
	p->chara_fire_tmr = p->chara_fire_rnd / p->chara_fire_cur;
	p->virus_fire_tmr = p->virus_fire_rnd / p->chara_fire_cur;


	p->virus_fire_level = N_LM2_FIRE_ON_SLOW;


	n_lm2_effect_init( bmp_bg );


	p->delayed_margin_onoff = n_false;


	// [!] : Moving Stars

	static n_bool stars_init = n_false;

	if ( stars_init == n_false )
	{

		stars_init = n_true;


		if ( p->zoom == 1 )
		{
			p->star_size = p->zoom;
		} else {
			p->star_size = p->zoom * 2;
		}

		n_bmp_new( &p->bmp[ N_LM2_STARS_INDEX ], p->star_size, p->star_size );

		if ( p->star_size > 2 )
		{
			n_bmp_flush_circle( &p->bmp[ N_LM2_STARS_INDEX ], p->star_size, n_bmp_white );
		} else {
			n_bmp_flush( &p->bmp[ N_LM2_STARS_INDEX ], n_bmp_white );
		}
//n_bmp_save_literal( &p->bmp[ N_LM2_STARS_INDEX ], "ret.bmp" );


		n_game_chara_bulk_zero( p->stars, N_LM2_STARS_MAX );

		n_game_chara_bulk_bmp( p->stars, N_LM2_STARS_MAX, &game.bmp, &p->bmp[ N_LM2_STARS_INDEX ], &p->bmp[ N_LM2_BMPBG_INDEX ], game.color );
		n_game_chara_bulk_src( p->stars, N_LM2_STARS_MAX, 0,0, p->star_size,p->star_size, 0,0 );
//n_bmp_save_literal( p->stars[ 0 ].chara, "ret2.bmp" );

		int i = 0;
		while( 1 )
		{//break;

			n_type_gfx x = n_random_range( N_BMP_SX( &game.bmp ) );
			n_type_gfx y = n_random_range( N_BMP_SY( &game.bmp ) );

			n_game_chara_pos( &p->stars[ i ], x, y );
			n_game_chara_prv( &p->stars[ i ] );


			if ( 0 == n_random_range( N_LM2_STARS_RAND ) )
			{
				p->stars[ i ].data = N_LM2_STARS_FAST;
			} else {
				p->stars[ i ].data = N_LM2_STARS_SLOW;
			}


			i++;
			if ( i >= N_LM2_STARS_MAX ) { break; }
		}

	}


	return;
}

void
n_lm2_levelup( n_lm2 *p )
{

	p->chara_fire_cur = n_posix_min( p->chara_fire_max, p->chara_fire_cur + 1 );
	p->chara_fire_tmr = p->chara_fire_rnd / p->chara_fire_cur;
	p->virus_fire_tmr = p->virus_fire_rnd / p->chara_fire_cur;


	p->level      = p->score / 100;
	p->item.data  = n_false;
	p->item.data |= n_lm2_power_laser_1 ( p );
	p->item.data |= n_lm2_power_laser_2 ( p );
	p->item.data |= n_lm2_power_gatling ( p );
	p->item.data |= n_lm2_power_stardust( p );
	p->item.data |= n_lm2_power_shield  ( p );


	if ( p->score >= 2500 )
	{
		p->virus_fire_level = N_LM2_FIRE_ON_TRICKY_FAST;
	} else
	if ( p->score >= 1000 )
	{
		p->virus_fire_level = N_LM2_FIRE_ON_TRICKY_SLOW;
	} else
	if ( p->score >=  500 )
	{
		p->virus_fire_level = N_LM2_FIRE_ON_FAST;
	} else {
		p->virus_fire_level = N_LM2_FIRE_ON_SLOW;
	}


	return;
}

void
n_lm2_input( n_lm2 *p )
{

	// Debug Center

	if ( n_win_is_input( VK_F1 ) )
	{
		p->score          = p->score + 100;
		p->score_counter  = p->score % 1000;
		p->chara_fire_cur = p->chara_fire_min + ( p->score / 100 );
		p->chara_fire_cur = n_posix_min( p->chara_fire_max, p->chara_fire_cur );
	}

	if ( n_win_is_input( VK_F2 ) )
	{
		p->item.data = n_true;
	}

	if ( n_win_is_input( VK_F3 ) )
	{
		p->debug_invincible = n_true;
	}


	// Player

	if ( n_game_input_loop( &p->input, VK_RIGHT ) )
	{
		p->chara.x = n_posix_min_n_type_gfx( p->max_x, p->chara.x + p->step_chara );
	}

	if ( n_game_input_loop(& p->input, VK_LEFT ) )
	{
		p->chara.x = n_posix_max( p->min_x, p->chara.x - p->step_chara );
	}


//n_game_hwndprintf_literal( "%d", n_game_input_loop( &p->input, VK_SPACE ) );

	n_bool fire = n_false;


	static u32 single_timer = 0;
	static u32  rapid_timer = 0;
	static int  rapid       = 1;
	static int  rapid_step  = 4;

	if ( n_game_input_loop( &p->input, VK_SPACE ) )
	{

		if ( n_game_timer( &single_timer, p->chara_fire_tmr / rapid ) )
		{
			fire  = n_true;
			rapid = n_posix_max( 1, rapid - rapid_step );
		}

		rapid_timer = n_posix_tickcount() + 100;

	} else {

		if ( rapid_timer > n_posix_tickcount() )
		{
			rapid += rapid_step;
			rapid_timer = n_posix_tickcount();
		}

	}

	if ( fire )
	{

		int i = 0;
		while( 1 )
		{

			n_game_chara *cf = &p->chara_fire[ i ];

			if ( cf->data == N_LM2_FIRE_OFF )
			{

				n_lm2_sound( p, N_LM2_SHOOT_INDEX );

				cf->data = N_LM2_FIRE_ON;
				n_game_chara_pos( cf, p->chara.x, p->chara.y - p->unit );

				break; 
			}

			i++;
			if ( i >= N_LM2_CHARA_FIRE_MAX ) { break; }
		}

	}


	return;
}

void
n_lm2_init( n_lm2 *p )
{

	// Global

	n_bmp_safemode = n_false;


	// Size

	n_type_gfx desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	p->zoom            = n_posix_max_n_type_gfx( 1, desktop_sx / 512 );

	{
		n_posix_char *cmdline = n_win_commandline_new();

		n_string_commandline_option_literal( "-lm2", cmdline );
		if ( n_false == n_string_is_empty( cmdline ) )
		{
			p->zoom = n_posix_max_n_type_gfx( 1, n_posix_atoi( cmdline ) );
		}

		n_string_free( cmdline );
	}

	p->csx             = 320 * p->zoom;
	p->csy             = 240 * p->zoom;
	p->unit            =  16 * p->zoom;
	p->hit_offset_x    =   3 * p->zoom;
	p->hit_offset_y    =   6 * p->zoom;

	p->min_x           = 0;
	p->mid_x           = n_game_centering( p->csx, p->unit );
	p->max_x           = p->csx - p->unit;
	p->msg1_x          = p->unit;
	p->msg2_x          = p->csx - p->unit - p->unit;

	p->step_chara      = (n_type_gfx) ( (double) 1.5 * p->zoom );
	p->step_chara_fire = p->step_chara * 2;
	p->step_virus_slow = p->step_chara / 2;
	p->step_virus_fast = p->step_chara / 1;

	p->virus_sx        = N_LM2_VIRUS_SX;
	p->virus_sy        = N_LM2_VIRUS_SY;
	p->virus_max       = N_LM2_VIRUS_MAX;
	p->chara_fire_min  = N_LM2_CHARA_FIRE_MIN;
	p->chara_fire_max  = N_LM2_CHARA_FIRE_MAX;
	p->chara_fire_rnd  = N_LM2_CHARA_FIRE_RND;
	p->virus_fire_rnd  = N_LM2_VIRUS_FIRE_RND;


	// System

	n_game_title_literal( "LINE MASHER 2" );

	game.sx    = p->csx;
	game.sy    = p->csy;
	game.fps   = 60;
	game.color = n_bmp_black;

	n_game_dwm_onoff();

	n_game_window_fixed();

	if ( IsZoomed( game.hwnd ) ) { ShowWindow( game.hwnd, SW_RESTORE ); }


	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );
	n_game_input_vk2button( &p->input, VK_SPACE, 0 );
	n_game_input_vk2button( &p->input, VK_SPACE, 1 );
	n_game_input_vk2button( &p->input, VK_SPACE, 2 );
	n_game_input_vk2button( &p->input, VK_SPACE, 3 );
	n_game_input_vk2button( &p->input, VK_SPACE, 4 );
	n_game_input_vk2button( &p->input, VK_SPACE, 5 );


	p->reset       = n_true;
	p->reset_timer = 0;

	n_lm2_chara_draw_blend = 1.0;
	p->transition_phase    = N_LM2_TRANSITION_FADE_IN;


	// Resources

	n_memory_zero( p->bmp, sizeof( n_bmp ) * N_LM2_BMP_ALL );

	n_game_rc_load_bmp_literal( &p->bmp[ 0 ], "LM2_BMP_0" );
	n_game_rc_load_bmp_literal( &p->bmp[ 1 ], "LM2_BMP_1" );
	n_game_rc_load_bmp_literal( &p->bmp[ 2 ], "LM2_BMP_2" );

	n_bmp_scaler_big( &p->bmp[ 0 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 1 ], p->zoom );
	n_bmp_scaler_big( &p->bmp[ 2 ], p->zoom );


	n_game_sound_bulk_zero( p->snd, N_LM2_SND_ALL );

	n_game_sound_init_literal( &p->snd_mute, game.hwnd,  LM2_WAV_M  ); n_game_sound_loop( &p->snd_mute );
	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd,  LM2_WAV_0  ); n_wav_smoother( &p->snd[ 0 ].wav );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd, "LM2_WAV_1" ); n_wav_smoother( &p->snd[ 1 ].wav );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd,  LM2_WAV_2  ); n_wav_smoother( &p->snd[ 2 ].wav );
	n_game_sound_init_literal( &p->snd[ 3 ], game.hwnd,  LM2_WAV_3  ); n_wav_smoother( &p->snd[ 3 ].wav );
	n_game_sound_init_literal( &p->snd[ 4 ], game.hwnd, "LM2_WAV_4" ); n_wav_smoother( &p->snd[ 4 ].wav );


	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sy                 = p->unit;
	gdi.sx                 = 0;
	gdi.style              = 0;//N_GDI_SMOOTH;

	gdi.base_color_bg      = game.color;
	gdi.base_color_fg      = 0;
	gdi.base_style         = N_GDI_BASE_SOLID;

	gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	gdi.icon               = n_posix_literal( "" );
	gdi.icon_index         = 0;
	gdi.icon_style         = N_GDI_ICON_DEFAULT;

	gdi.text               = NULL;
	gdi.text_font          = n_posix_literal( "Verdana" );
	gdi.text_size          = p->unit;
	gdi.text_color_main    = n_bmp_rgb( 255,255,255 );
	gdi.text_color_contour = n_bmp_rgb(   0,200,255 );
	gdi.text_style         = N_GDI_TEXT_CONTOUR;
	gdi.text_fxsize2       = 1;

	p->gdi = gdi;


	if ( game.dwm_onoff )
	{
		n_lm2_gradient_refresh( p, game.color, game.color );
	} else {
		n_lm2_gradient_refresh( p, game.color, n_bmp_rgb( 0,100,150 ) );
	}


	return;
}

void
n_lm2_loop( n_lm2 *p )
{

	// Control

//n_game_hwndprintf_literal( "%f", n_lm2_chara_draw_blend );
/*
	if ( n_win_is_input( VK_CONTROL ) )
	{
		p->transition_phase = N_LM2_TRANSITION_FADE_OUT;
	}
*/
	if ( p->transition_phase != N_LM2_TRANSITION_NONE )
	{
		if ( p->transition_phase == N_LM2_TRANSITION_FADE_IN )
		{
			n_lm2_chara_draw_blend -= 0.05;
			if ( n_lm2_chara_draw_blend <= 0.0 )
			{
				p->transition_phase = N_LM2_TRANSITION_NONE;
			}
		} else
		if ( p->transition_phase == N_LM2_TRANSITION_FADE_OUT )
		{
			n_lm2_chara_draw_blend += 0.05;
			if ( n_lm2_chara_draw_blend >= 1.0 )
			{
				p->transition_phase = N_LM2_TRANSITION_FADE_IN;

				n_lm2_vibrate_off( p );

				n_lm2_reset( p );
				n_bmp_flush_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &game.bmp );
			}
		}
	}

	if ( ( p->reset )&&( n_game_timer( &p->reset_timer, 1000 ) ) )
	{
		p->reset = n_false;

		n_lm2_vibrate_off( p );

		n_lm2_reset( p );
		n_bmp_flush_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &game.bmp );

		return;
	}


	// [Mechanism]
	//
	//	[Flow]
	//	Erase => Input => Draw
	//
	//	[Rendering Order]
	//	score => virus => virus_fire => effect => chara => chara_fire => item


	int i;


	// Erase : erase with previous position

	n_game_chara_bulk_erase( p->stars, N_LM2_STARS_MAX );


	//n_bmp_box( &game.bmp, 0,0, p->csx,p->unit, game.color );
	n_bmp_fastcopy( &p->bmp[ N_LM2_BMPBG_INDEX ], &game.bmp, 0,0, p->csx,p->unit, 0,0 );


	n_game_chara_bulk_erase( p->virus     , p->virus_max );
	n_game_chara_bulk_erase( p->virus_fire, p->virus_max );


	n_lm2_effect_loop_erase();


	n_game_chara_erase( &p->chara );


	i = 0;
	while( 1 )
	{//break;

		n_game_chara *cf = &p->chara_fire[ i ];

		if ( cf->data != N_LM2_FIRE_OFF )
		{

			n_game_chara_erase( cf );

			cf->y -= p->step_chara_fire;
			if ( cf->y < -p->unit ) { cf->data = N_LM2_FIRE_OFF; }

			if ( cf->data == N_LM2_FIRE_ON_DOUBLE ) { cf->data = N_LM2_FIRE_OFF; }

			if ( p->power >= N_LM2_POWER_GATLING )
			{

				double o = sin( ( 2 * M_PI ) * p->gatling[ i ] );
				double a = p->unit;

				if ( p->power >= N_LM2_POWER_STARDUST ) { a *= 1 + n_game_random( 2 ); }

				cf->x = p->chara.x + (n_type_gfx) ( a * o );

				p->gatling[ i ] += (double) 0.003 * p->level;

			}

		}

		i++;
		if ( i >= p->chara_fire_max ) { break; }
	}

	if ( p->delayed_margin_onoff )
	{

		p->delayed_margin_onoff = n_false;

		int i = 0;
		while( 1 )
		{

			n_game_chara *cf = &p->chara_fire[ i ];

			cf->srcx = p->unit * n_posix_min( 4, p->power );

			if ( p->power == N_LM2_POWER_LASER_1 )
			{
				cf->mx = p->zoom * 6;
				cf->my = p->zoom * 2;
			} else
			if ( p->power == N_LM2_POWER_LASER_2 )
			{
				cf->mx = p->zoom * 6;
				cf->my = p->zoom * 2;
			} else
			if ( p->power == N_LM2_POWER_GATLING )
			{
				cf->mx = p->zoom * 6;
				cf->my = p->zoom * 4;
			} else
			if ( p->power == N_LM2_POWER_STARDUST )
			{
				cf->mx = p->zoom * 3;
				cf->my = p->zoom * 3;
			}// else

			i++;
			if ( i >= p->chara_fire_max ) { break; }
		}

	}


	if ( p->item.data )
	{
		n_game_chara_erase( &p->item );
	}


	// Input

	if ( p->transition_phase == N_LM2_TRANSITION_NONE )
	{
		n_lm2_input( p );
	}


	// Draw

	i = 0;
	while( 1 )
	{//break;

		if ( p->stars[ i ].data == N_LM2_STARS_FAST )
		{
			p->stars[ i ].y += p->zoom * 2;
		} else {
			p->stars[ i ].y += p->zoom * 1;
		}

		if ( p->stars[ i ].y >= ( game.sy + N_BMP_SY( p->stars[ i ].chara ) ) )
		{
			n_type_gfx x = n_random_range( N_BMP_SX( &game.bmp ) );
			n_type_gfx y = N_BMP_SY( p->stars[ i ].chara );

			n_game_chara_pos( &p->stars[ i ], x, -y );
			n_game_chara_prv( &p->stars[ i ] );

			if ( 0 == n_random_range( N_LM2_STARS_RAND ) )
			{
				p->stars[ i ].data = N_LM2_STARS_FAST;
			} else {
				p->stars[ i ].data = N_LM2_STARS_SLOW;
			}
		}


		i++;
		if ( i >= N_LM2_STARS_MAX ) { break; }
	}

	n_game_chara_bulk_draw( p->stars, N_LM2_STARS_MAX );

	i = 0;
	while( 1 )
	{//break;

		n_game_chara *c  = &p->chara;
		n_game_chara *v  = &p->virus     [ i ];
		n_game_chara *vf = &p->virus_fire[ i ];

		if ( v->data == N_LM2_VIRUS_STOP )
		{

			if ( 0 == n_game_random( p->virus_fire_tmr ) )
			{
				v->data = N_LM2_VIRUS_FIRE;
			}

			v->srcx = p->unit * 0;
			n_lm2_chara_draw( v );

		} else
		if ( v->data == N_LM2_VIRUS_FIRE )
		{

			if ( vf->data == N_LM2_FIRE_OFF )
			{
				vf->data = N_LM2_FIRE_ON + n_game_random( p->virus_fire_level );
				n_game_chara_pos( vf, v->x, v->y );
			} else
			if ( vf->data == N_LM2_FIRE_ON_SLOW )
			{
				v ->srcx = p->unit * 1;
				vf->srcx = p->unit * 3;
				vf->mx   = p->zoom * 4;
				vf->my   = p->zoom * 4;
				vf->y += p->step_virus_slow;
			} else
			if ( vf->data == N_LM2_FIRE_ON_FAST )
			{
				v ->srcx = p->unit * 1;
				vf->srcx = p->unit * 3;
				vf->mx   = p->zoom * 4;
				vf->my   = p->zoom * 4;
				vf->y += p->step_virus_fast;
			} else
			if ( vf->data == N_LM2_FIRE_ON_TRICKY_SLOW )
			{ 

				v->srcx = p->unit * 1;

				if ( vf->x > c->x )
				{
					vf->x -= p->step_virus_slow;
				} else {
					vf->x += p->step_virus_slow;
				}

				vf->y += p->step_virus_slow;

				vf->srcx = ( p->unit * 3 ) - ( p->unit * ( vf->x & 1 ) );
				if ( vf->srcx == ( p->unit * 3 ) )
				{
					vf->mx   = p->zoom * 3;
					vf->my   = p->zoom * 3;
				} else {
					vf->mx   = p->zoom * 4;
					vf->my   = p->zoom * 4;
				}

			} else
			if ( vf->data == N_LM2_FIRE_ON_TRICKY_FAST )
			{ 

				v->srcx = p->unit * 1;

				if ( vf->x > c->x )
				{
					vf->x -= p->step_virus_slow;
				} else {
					vf->x += p->step_virus_slow;
				}

				vf->y += p->step_virus_fast;

				vf->srcx = ( p->unit * 3 ) - ( p->unit * ( vf->x & 1 ) );
				if ( vf->srcx == ( p->unit * 3 ) )
				{
					vf->mx   = p->zoom * 3;
					vf->my   = p->zoom * 3;
				} else {
					vf->mx   = p->zoom * 4;
					vf->my   = p->zoom * 4;
				}

			}


			if ( vf->y > p->csy )
			{

				v ->data = N_LM2_VIRUS_STOP;
				vf->data = N_LM2_FIRE_OFF;

			} else
			if (
				( p->debug_invincible == n_false )
				&&
				( vf->y >= c->y )
				&&
				( n_game_chara_is_hit_offset( vf, c, p->hit_offset_x,p->hit_offset_y, 0,0 ) )
				&&
				( p->transition_phase == N_LM2_TRANSITION_NONE )
			)
			{

				// GAME OVER

				if ( p->power >= N_LM2_POWER_SHIELD )
				{

					n_lm2_sound( p, N_LM2_PHOOT_INDEX );

				} else {

					n_lm2_sound( p, N_LM2_BWOPP_INDEX );

					n_lm2_vibrate_on( p );

					p->transition_phase = N_LM2_TRANSITION_FADE_OUT;

				}

				n_lm2_effect_go( c );

			}


			n_lm2_chara_draw( v  );
			n_lm2_chara_draw( vf );

		} else
		if ( 0 == n_game_random( p->virus_fire_tmr ) )
		{

			// Revive

			v->data = N_LM2_VIRUS_STOP;

		}


		int ii = 0;
		while( v->data != N_LM2_VIRUS_DEAD )
		{//break;

			n_game_chara *cf = NULL;
			while( 1 )
			{

				cf = &p->chara_fire[ ii ];
				ii++;

				if ( cf->data != N_LM2_FIRE_OFF ) { break; }
				if ( ii >= p->chara_fire_max ) { break; }
			}
			if ( ii >= p->chara_fire_max ) { break; }


			if ( n_game_chara_is_hit( cf, v ) )
			{

				n_lm2_sound( p, N_LM2_CHIPP_INDEX );

				n_lm2_effect_go( v );


				// Double Shot : one shot two viruses

				// [!] : laser is default behavior

				if ( p->power == N_LM2_POWER_NONE )
				{
					if ( cf->data == N_LM2_FIRE_ON )
					{
						cf->data = N_LM2_FIRE_ON_DOUBLE;
					} else {
						cf->data = N_LM2_FIRE_OFF;
					}
				}


				v ->data = N_LM2_VIRUS_DEAD;
				vf->data = N_LM2_FIRE_OFF;


				p->score++;
				if ( p->hiscore < p->score ) { p->hiscore = p->score; }

				p->score_counter++;
				if ( p->score_counter >= 100 )
				{
					p->score_counter = 0;
					n_lm2_levelup( p );
				}

			} else
			if (
				( p->power >= N_LM2_POWER_LASER_2 )
				&&
				( vf->data != N_LM2_FIRE_OFF )
				&&
				( n_game_chara_is_hit( cf, vf ) )
			)
			{

				// Virus Fire Eraser

				if ( p->power < N_LM2_POWER_GATLING ) { cf->data = N_LM2_FIRE_OFF; }
				v ->data = N_LM2_VIRUS_STOP;
				vf->data = N_LM2_FIRE_OFF;

			}

		}


		i++;
		if ( i >= p->virus_max ) { break; }
	}


	n_lm2_effect_loop_draw();


	if (
		( p->transition_phase == N_LM2_TRANSITION_NONE )
		||
		( p->transition_phase == N_LM2_TRANSITION_FADE_IN )
	)
	{
		n_lm2_chara_draw( &p->chara );
	}


	i = 0;
	while( 1 )
	{

		n_game_chara *cf = &p->chara_fire[ i ];

		if ( cf->data != N_LM2_FIRE_OFF )
		{
			n_lm2_chara_draw( cf );
		}

		i++;
		if ( i >= p->chara_fire_max ) { break; }
	}

	if ( p->item.data )
	{

		p->item.y += p->step_virus_slow;

		if ( p->item.y > p->csy )
		{
			p->item.data = n_false;
			p->item.y    = -p->unit;
		}

		if ( n_game_chara_is_hit_offset( &p->item, &p->chara, p->hit_offset_x,p->hit_offset_y, 0,0 ) )
		{

			p->item.data = n_false;
			p->item.y    = -p->unit;

			n_game_chara_erase( &p->item  );
			n_lm2_chara_draw  ( &p->chara );


			p->power++;
			p-> item.srcx = p->unit * n_posix_min( 4, p->power     );
			p->chara.srcx = p->unit * n_posix_min( 4, p->power - 1 );

			p->delayed_margin_onoff = n_true;

			n_lm2_sound( p, N_LM2_WOOOW_INDEX );

		} else {

			n_lm2_chara_draw( &p->item );

		}

	}


	// [!] : this position is important for hiscore

	n_lm2_digitbitmap( p );


	n_game_refresh_on();
	return;
}

void
n_lm2_exit( n_lm2 *p )
{

	int i = 0;
	while( 1 )
	{

		n_bmp_free( &p->bmp[ i ] );

		i++;
		if ( i >= N_LM2_BMP_ALL ) { break; }
	}

	i = 0;
	while( 1 )
	{

		n_game_sound_exit( &p->snd[ i ] );

		i++;
		if ( i >= N_LM2_SND_ALL ) { break; }
	}

	n_game_sound_exit( &p->snd_mute );


	n_lm2_effect_exit();


	n_game_input_exit( &p->input );


	n_lm2_zero( p );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_lm2_zero( &lm2 );
	n_lm2_init( &lm2 );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_lm2_exit( &lm2 );
		n_lm2_init( &lm2 );
		n_game_reset();
	}

	n_lm2_loop( &lm2 );


	return;
}

void
n_game_exit( void )
{

	n_lm2_exit( &lm2 );


	return;
}

#endif // #ifndef N_GAMECONSOLE

