// Nonnon Win32 System Information
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_CPU
#define _H_NONNON_WIN32_SYSINFO_CPU




#include "../registry.c"




// internal
void
n_sysinfo_cpu_time_XP_or_later( u64 *cputime )
{

	if ( cputime == NULL ) { return; }


	// [!] : WinXP or later

	HMODULE hmod = LoadLibrary( n_posix_literal( "kernel32.dll" ) );
	if ( hmod == NULL ) { return; }

	FARPROC func = GetProcAddress( hmod, "GetSystemTimes" );
	if ( func != NULL )
	{

		// [!] : <winbase.h>
		//
		//	typedef struct _FILETIME {
		//		DWORD dwLowDateTime;
		//		DWORD dwHighDateTime;
		//	} FILETIME,*PFILETIME,*LPFILETIME;

		FILETIME i,k,u;


		(*func)( &i, &k, &u );

		cputime[ 0 ] = i.dwLowDateTime + ( (u64) i.dwHighDateTime << 32 );
		cputime[ 1 ] = k.dwLowDateTime + ( (u64) k.dwHighDateTime << 32 );
		cputime[ 2 ] = u.dwLowDateTime + ( (u64) u.dwHighDateTime << 32 );

	}

	FreeLibrary( hmod );


	return;
}

// internal
void
n_sysinfo_cpu_time_XP_or_earlier( u64 *cputime )
{

	if ( cputime == NULL ) { return; }


	// [!] : WinNT/2000/XP

	HMODULE hmod = LoadLibrary( n_posix_literal( "ntdll.dll" ) );
	if ( hmod == NULL ) { return; }

	FARPROC func = GetProcAddress( hmod, "NtQuerySystemInformation" );
	if ( func != NULL )
	{

		// [!] : <ddk/ntapi.h> : SystemProcessorTimes = 8

		// [!] : "cputime" is not sizeof( SYSTEM_PROCESSOR_TIMES ) == 44byte
		//
		//	typedef struct _SYSTEM_PROCESSOR_TIMES {
		//		LARGE_INTEGER  IdleTime;
		//		LARGE_INTEGER  KernelTime;
		//		LARGE_INTEGER  UserTime;
		//		LARGE_INTEGER  DpcTime;
		//		LARGE_INTEGER  InterruptTime;
		//		ULONG  InterruptCount;
		//	} SYSTEM_PROCESSOR_TIMES, *PSYSTEM_PROCESSOR_TIMES;

		u64 spt[ 6 ];


		(*func)( 8, spt, sizeof( u64 ) * 6, NULL );

		n_memory_copy( spt, cputime, sizeof( u64 ) * 3 );

	}

	FreeLibrary( hmod );


	return;
}

// internal
void
n_sysinfo_cpu_time_NT( u64 *cputime )
{

	// [!] : Win9x : don't link to "libntdll.a"
	//
	//	DLL is exist, but fail to get data


	if ( cputime == NULL ) { return; }

	ZeroMemory( cputime, sizeof( u64 ) * 3 );


	if ( n_sysinfo_version_xp_or_later() )
	{
		n_sysinfo_cpu_time_XP_or_later  ( cputime );
	} else {
		n_sysinfo_cpu_time_XP_or_earlier( cputime );
	}


	return;
}

// internal
int
n_sysinfo_cpu_ratio_NT( void )
{

	static n_posix_bool is_first = n_posix_true;
	static u64          prv[ 3 ];

	if ( is_first )
	{
		is_first = n_posix_false;
		n_sysinfo_cpu_time_NT( prv );
	}


	u64 cur[ 3 ];
	n_sysinfo_cpu_time_NT( cur );

	double idle = (double) cur[ 0 ] - prv[ 0 ];
	double kern = (double) cur[ 1 ] - prv[ 1 ];
	double user = (double) cur[ 2 ] - prv[ 2 ];

	n_memory_copy( cur, prv, sizeof( u64 ) * 3 );


	double percent = 0;
	if ( user != 0 ) { percent = 100 * ( user / ( idle + kern + user ) ); }


	return (int) percent;
}

// internal
int
n_sysinfo_cpu_ratio_95( void )
{

	u32 percent = 0;


	HKEY  hkey;
	DWORD ret = RegOpenKeyEx
	(
		HKEY_DYN_DATA,
		n_posix_literal( "PerfStats\\StatData" ),
		0,
		KEY_READ,
		&hkey
	);

	if ( ret != ERROR_SUCCESS ) { return (int) percent; }


	u32 byte = sizeof( u32 );

	RegQueryValueEx
	(
		hkey,
		n_posix_literal( "KERNEL\\CPUUsage" ),
		NULL,NULL,
		(void*) &percent, &byte
	);


	RegCloseKey( hkey );


	return (int) percent;
}

int
n_sysinfo_cpu_ratio( void )
{

	int ret;


	if ( n_sysinfo_version_9x() )
	{
		ret = n_sysinfo_cpu_ratio_95();
	} else {
		ret = n_sysinfo_cpu_ratio_NT();
	}


	return ret;
}


#endif // _H_NONNON_WIN32_SYSINFO_CPU

