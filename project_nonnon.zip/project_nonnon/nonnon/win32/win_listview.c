// Nonnon Mail Manager
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [Needed] : link  : -lcomctl32




#ifndef _H_NONNON_WIN32_WIN_LISTVIEW
#define _H_NONNON_WIN32_WIN_LISTVIEW




#include "./win.c"


#include <commctrl.h>




// [Patch]

#define n_HDS_CHECKBOXES 0x0400

#define n_HDF_CHECKBOX 0x0040
#define n_HDF_CHECKED  0x0080

#define n_HDF_SORTUP   0x0400
#define n_HDF_SORTDOWN 0x0200

#define n_HDN_ITEMSTATEICONCLICK ( HDN_FIRST - 16 )




// [!] : length is limited

#define N_WIN_LISTVIEW_CCH ( MAX_PATH + 1 )




void
n_win_listview_gui( HWND hwnd_parent, HWND *hgui, DWORD lvs, DWORD lvs_ex )
{

	if ( hgui == NULL ) { return; }


	InitCommonControls();


	(*hgui) = CreateWindowEx
	(
		WS_EX_CLIENTEDGE,
		n_posix_literal( "SysListView32" ),
		n_posix_literal( "" ),
		WS_CHILD | WS_VISIBLE,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);


	// [Mechanism]
	//
	//	LVS_REPORT         : details mode
	//	LVS_SHOWSELALWAYS  : selection will be grayed when unfocused
	//	LVS_NOSORTHEADER   : header will be unpushable
	//	LVS_NOCOLUMNHEADER : header will be disappeared
	//	LVS_SORTASCENDING  : sorting in x == 0
	//	LVS_EDITLABELS     : first item only editable

	n_win_style_add
	(
		(*hgui),
		lvs
		//  LVS_REPORT
		//| LVS_AUTOARRANGE  | LVS_SORTASCENDING
		//| LVS_SHOWSELALWAYS
		////| LVS_EDITLABELS 
	);


	// [Mechanism]
	//
	//	LVS_EX_CHECKBOXES     : IE3 : the first item will be checkbox
	//	LVS_EX_FULLROWSELECT  : IE3 : select a row at once
	//	LVS_EX_GRIDLINES      : IE3 : grid line will appear
	//	LVS_EX_HEADERDRAGDROP : IE3 : headers will be draggable
	//	LVS_EX_FLATSB         : IE4 : scrollbars will be flat style

	ListView_SetExtendedListViewStyle
	(
		(*hgui),
		lvs_ex
		//  LVS_EX_CHECKBOXES | LVS_EX_FULLROWSELECT
		//| LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP
		////| LVS_EX_FLATSB
	);


	return;
}

#define n_win_listview_header_set_literal( h, x, s ) n_win_listview_header_set( h, x, n_posix_literal( s ) )

void
n_win_listview_header_set( HWND hgui, int x, n_posix_char *text )
{

	LVCOLUMN col; ZeroMemory( &col, sizeof( LVCOLUMN ) );

	col.mask       = LVCF_TEXT | LVCF_WIDTH;
	col.fmt        = 0;
	col.cx         = 0;
	col.pszText    = text;
	col.cchTextMax = 0;
	col.iSubItem   = 0;

	ListView_InsertColumn( hgui, x, &col );


	return;
}

int
n_win_listview_header_count( HWND hgui )
{

	HWND hwnd_header = ListView_GetHeader( hgui );

	return Header_GetItemCount( hwnd_header );
}

int
n_win_listview_item_count( HWND hgui )
{
	return ListView_GetItemCount( hgui );
}

void
n_win_listview_header_checkbox( HWND hgui, int x )
{

	// [Needed] : Vista or later


	HWND hwnd_header = ListView_GetHeader( hgui );


	n_win_style_add( hwnd_header, n_HDS_CHECKBOXES );


	HDITEM h;
	h.mask = HDI_FORMAT;

	Header_GetItem( hwnd_header, x, &h );


	h.mask = HDI_FORMAT;
	h.fmt  = h.fmt | n_HDF_CHECKBOX;// | n_HDF_CHECKED;

	Header_SetItem( hwnd_header, x, &h );


	return;
}

void
n_win_listview_header_check( HWND hgui, n_posix_bool toggle )
{

	int sy = n_win_listview_item_count( hgui );
	int  y = 0;
	while( 1 )
	{

		if ( y >= sy ) { break; }


		ListView_SetCheckState( hgui, y, toggle );


		y++;

	}


	return;
}

void
n_win_listview_header_sort_set( HWND hgui, int x, int v )
{

	HWND hwnd_header = ListView_GetHeader( hgui );


	HDITEM h;
	h.mask = HDI_FORMAT;

	Header_GetItem( hwnd_header, x, &h );


	h.mask = HDI_FORMAT;
	h.fmt  = h.fmt & ~( n_HDF_SORTUP | n_HDF_SORTDOWN );
	h.fmt  = h.fmt | v;

	Header_SetItem( hwnd_header, x, &h );


	return;
}

int
n_win_listview_header_sort_get( HWND hgui, int x )
{

	HWND hwnd_header = ListView_GetHeader( hgui );


	HDITEM h;
	h.mask = HDI_FORMAT;

	Header_GetItem( hwnd_header, x, &h );

	if ( h.fmt & n_HDF_SORTUP )
	{
		return n_HDF_SORTUP;
	} else
	if ( h.fmt & n_HDF_SORTDOWN )
	{
		return n_HDF_SORTDOWN;
	}


	return 0;
}

void
n_win_listview_header_sort_all( HWND hgui, int x, int sort )
{

	int sx = n_win_listview_header_count( hgui );
	int i  = 0;
	while( 1 )
	{

		if ( i >= sx ) { break; }


		int v = 0;
		if ( i == x ) { v = sort; }

		n_win_listview_header_sort_set( hgui, i, v );


		i++;

	}


	return;
}

void
n_win_listview_header_adjust( HWND hgui )
{

	n_win_redraw_off( hgui );


	// [Patch] : the last column has the rest of width

	int header_x = n_win_listview_header_count( hgui );
	n_win_listview_header_set_literal( hgui, header_x, "" );


	int sx = n_win_listview_header_count( hgui );
	int  x = 0;
	while( 1 )
	{

		if ( x >= sx ) { break; }


		ListView_SetColumnWidth( hgui, x, LVSCW_AUTOSIZE_USEHEADER );


		x++;

	}


	ListView_DeleteColumn( hgui, header_x );


	n_win_redraw_on( hgui );


	return;
}

#define n_win_listview_item_is_checked( hgui, y ) ListView_GetCheckState( hgui, y )
#define n_win_listview_item_del(        hgui, y ) ListView_DeleteItem(    hgui, y )

n_posix_bool
n_win_listview_item_get( HWND hgui, int x, int y, n_posix_char *str, int cch )
{

	if ( y == -1 ) { y = ListView_GetNextItem( hgui, -1, LVNI_FOCUSED ); }


	LVITEM item; ZeroMemory( &item, sizeof( LVITEM ) );

	item.mask       = LVIF_TEXT | LVIF_PARAM;
	item.iItem      = y;
	item.iSubItem   = x;
	item.state      = 0;
	item.stateMask  = 0;
	item.pszText    = str;
	item.cchTextMax = cch;
	item.iImage     = 0;
	item.lParam     = y;

	//item.mask &= ~LVIF_PARAM;

	n_posix_bool ret = ListView_GetItem( hgui, &item );
//n_posix_debug_literal( "%d : %d %d", ret, x, y );


	return ret;
}

#define n_win_listview_item_set_literal( h, x, y, t ) n_win_listview_item_set( h, x, y, n_posix_literal( t ) )

void
n_win_listview_item_set( HWND hgui, int x, int y, n_posix_char *str )
{

	LVITEM item; ZeroMemory( &item, sizeof( LVITEM ) );

	item.mask       = LVIF_TEXT | LVIF_PARAM;
	item.iItem      = y;
	item.iSubItem   = x;
	item.state      = 0;
	item.stateMask  = 0;
	item.pszText    = str;
	item.cchTextMax = 0;
	item.iImage     = 0;
	item.lParam     = y;


	if ( x == 0 )
	{

		ListView_InsertItem( hgui, &item );

	} else {

		// [Needed] : reason is unknown : ListView_SetItem() will fail

		item.mask &= ~LVIF_PARAM;

		ListView_SetItem( hgui, &item );

	}


	return;
}

void
n_win_listview_item_reset( HWND hgui )
{

	n_win_redraw_off( hgui );


	ListView_DeleteAllItems( hgui );


	// [Needed] : reverse order

	int x = n_win_listview_header_count( hgui ) - 1;
	while( 1 )
	{

		ListView_DeleteColumn( hgui, x );

		x--;
		if ( x < 0 ) { break; }
	}


	n_win_redraw_on( hgui );


	return;
}

static int n_win_listview_item_sort_x    = 0;
static int n_win_listview_item_sort_sort = 0;

int CALLBACK
n_win_listview_item_sort_CompareFunc( LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort )
{
//n_posix_debug_literal( "%d : %d %d", n_win_listview_item_sort_x, lParam1, lParam2 );

	// [!] : lParam1 and lParam2 have zero always when LVITEM.lParam is not set

	HWND hgui = (HWND) lParamSort;


	// [Needed] : item id and position will be different

	LV_FINDINFO lvf;
	lvf.flags  = LVFI_PARAM;

	lvf.lParam = lParam1;
	int item_1 = ListView_FindItem( hgui, -1, &lvf );

	lvf.lParam = lParam2;
	int item_2 = ListView_FindItem( hgui, -1, &lvf );

//n_posix_debug_literal( "%d : %d %d", n_win_listview_item_sort_x, item_1, item_2 );

	int sort = 1;
	if ( n_win_listview_item_sort_sort == n_HDF_SORTDOWN ) { sort = -1; }


	int ret = 0;

	if ( n_win_listview_item_sort_x == 0 )
	{

		n_posix_bool onoff_1 = ListView_GetCheckState( hgui, item_1 );
		n_posix_bool onoff_2 = ListView_GetCheckState( hgui, item_2 );

		ret = onoff_2 - onoff_1;

	} else {

		n_posix_char str1[ N_WIN_LISTVIEW_CCH ]; ListView_GetItemText( hgui, item_1, n_win_listview_item_sort_x, str1, N_WIN_LISTVIEW_CCH );
		n_posix_char str2[ N_WIN_LISTVIEW_CCH ]; ListView_GetItemText( hgui, item_2, n_win_listview_item_sort_x, str2, N_WIN_LISTVIEW_CCH );

		int n1 = n_posix_atoi( str1 );
		int n2 = n_posix_atoi( str2 );

		if ( ( 0 != n1 )&&( 0 != n2 ) )
		{

			if ( n1 > n2 )
			{
				ret = 1;
			} else
			if ( n1 < n2 )
			{
				ret = -1;
			} else {
				ret = 0;
			}

		} else {

			ret = n_posix_strcmp( str1, str2 );

		}

	}


	return ret * sort;
}

void
n_win_listview_item_sort( HWND hgui, int x )
{

	n_win_listview_item_sort_x = x;

	n_win_listview_item_sort_sort = n_win_listview_header_sort_get( hgui, x );
	if ( n_win_listview_item_sort_sort == n_HDF_SORTUP )
	{
		n_win_listview_item_sort_sort = n_HDF_SORTDOWN;
	} else
	if ( n_win_listview_item_sort_sort == n_HDF_SORTDOWN )
	{
		n_win_listview_item_sort_sort = n_HDF_SORTUP;
	} else {
		n_win_listview_item_sort_sort = n_HDF_SORTUP;
	}

	ListView_SortItems( hgui, n_win_listview_item_sort_CompareFunc, (LPARAM) hgui );

	n_win_listview_header_sort_all( hgui, x, n_win_listview_item_sort_sort );


	return;
}

#define n_win_listview_item_debug_cch( h, y, f ) n_win_listview_item_debug( h, y, NULL, f )

#define n_win_listview_item_debug_cch_literal( h, y,    f ) n_win_listview_item_debug( h, y, NULL, n_posix_literal( f ) )
#define n_win_listview_item_debug_literal(     h, y, s, f ) n_win_listview_item_debug( h, y,    s, n_posix_literal( f ) )

int
n_win_listview_item_debug( HWND hgui, int y, n_posix_char *str_ret, const n_posix_char *filter )
{

	if ( str_ret != NULL ) { n_string_truncate( str_ret ); }

	int cch = 0;

	if ( n_string_is_same_literal( "all", filter ) )
	{

		int sx = n_win_listview_header_count( hgui );
		int x  = 0;
		while( 1 )
		{//break;

			if ( x >= sx ) { break; }


			n_posix_char s[ N_WIN_LISTVIEW_CCH ]; n_string_truncate( s );
			n_win_listview_item_get( hgui, x,y, s, N_WIN_LISTVIEW_CCH );

			if ( str_ret == NULL )
			{
				cch += n_posix_strlen( s ) + n_posix_strlen( N_STRING_CRLF );
			} else {
				n_posix_strcat( str_ret, s );
				n_posix_strcat( str_ret, N_STRING_CRLF );
			}

			x++;

		}

		return cch;
	}


	int sx = n_win_listview_header_count( hgui );
	int x  = 0;
	while( 1 )
	{//break;

		int count = n_string_parameter_count( filter, N_STRING_COMMA, N_STRING_EMPTY );
		int i     = 0;
		while( 2 )
		{//break;

			if ( i >= count ) { break; }

			n_posix_char ret[ N_WIN_LISTVIEW_CCH ]; n_string_truncate( ret );
			n_string_parameter( filter, N_STRING_COMMA, N_STRING_EMPTY, i, ret );
			int xx = n_posix_atoi( ret );

			if ( x == xx )
			{
				n_posix_char s[ N_WIN_LISTVIEW_CCH ]; n_string_truncate( s );
				n_win_listview_item_get( hgui, x,y, s, N_WIN_LISTVIEW_CCH );

				if ( str_ret == NULL )
				{
					cch += n_posix_strlen( s ) + n_posix_strlen( N_STRING_CRLF );
				} else {
					n_posix_strcat( str_ret, s );
					n_posix_strcat( str_ret, N_STRING_CRLF );
				}
			}

			i++;

		}

		x++;
		if ( x >= sx ) { break; }
	}

//n_posix_debug_literal( "%s", str_ret );


	return cch;
}

void
n_win_listview_item_filter( HWND hgui, const n_posix_char *query )
{

	if ( n_string_is_empty( query ) ) { return; }


	n_win_redraw_off( hgui );


	n_posix_bool delete = n_posix_true;

	int sx = n_win_listview_header_count( hgui );
	int  x = 0;
	int  y = n_win_listview_item_count( hgui ) - 1;
	while( 1 )
	{//break;

		n_posix_char str[ N_WIN_LISTVIEW_CCH ]; n_string_truncate( str );
		n_win_listview_item_get( hgui, x,y, str, N_WIN_LISTVIEW_CCH );

		if ( n_string_search_simple( str, query ) )
		{
//n_posix_debug_literal( "%s", str );
			delete = n_posix_false;
		}

		x++;
		if ( x >= sx )
		{

			x = 0;

			if ( delete ) { n_win_listview_item_del( hgui, y ); }
			delete = n_posix_true;

			y--;
			if ( y < 0 ) { break; }
		}
	}


	n_win_redraw_on( hgui );


	return;
}


#endif // _H_NONNON_WIN32_WIN_LISTVIEW

