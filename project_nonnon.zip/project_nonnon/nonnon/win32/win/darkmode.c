// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DARKMODE
#define _H_NONNON_WIN32_WIN_DARKMODE




#include "../../neutral/bmp/all.c"


#include "../registry.c"


#include "../gdi/color.c"




#define n_win_darkmode_bg            RGB(  66, 66, 66 )
#define n_win_darkmode_bg_argb n_bmp_rgb(  66, 66, 66 )

#define n_win_darkmode_fg            RGB( 240,240,240 )
#define n_win_darkmode_fg_argb n_bmp_rgb( 240,240,240 )




static n_posix_bool n_win_darkmode_onoff = n_posix_false;




static HBRUSH n_win_darkmode_brush = NULL;

void
n_win_darkmode_brush_atexit( void )
{

	DeleteObject( n_win_darkmode_brush );

	return;
}

void
n_win_darkmode_brush_make( void )
{

	n_win_darkmode_brush = CreateSolidBrush( n_win_darkmode_bg );

	return;
}




void
n_win_darkmode( void )
{

	u32 light_onoff = (u32) n_posix_true;


	n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" );
	n_posix_char *section = n_posix_literal( "AppsUseLightTheme" );

	DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &light_onoff, sizeof( u32 ) );

	if ( ret != ERROR_SUCCESS ) { light_onoff = n_posix_true; }


	n_win_darkmode_onoff = ( light_onoff == n_posix_false );
//n_win_darkmode_onoff = n_posix_true;


	return;
}

LRESULT
n_win_darkmode_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CTLCOLORSTATIC :

		if ( n_win_darkmode_onoff )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			//return (LRESULT) GetStockObject( BLACK_BRUSH );

			if ( n_win_darkmode_brush == NULL )
			{
				n_win_darkmode_brush_make();
				atexit( n_win_darkmode_brush_atexit );
			}

			return (LRESULT) n_win_darkmode_brush;
		}

	break;


	} // switch


	return 0;
}

HBRUSH
n_win_darkmode_brush_bg( int color_id_fallback )
{

	HBRUSH ret;

	if ( n_win_darkmode_onoff )
	{
		//ret = GetStockObject( BLACK_BRUSH );

		if ( n_win_darkmode_brush == NULL )
		{
			n_win_darkmode_brush_make();
			atexit( n_win_darkmode_brush_atexit );
		}
		ret = n_win_darkmode_brush;
	} else {
		ret = GetSysColorBrush( color_id_fallback );
	}

	return ret;
}

COLORREF
n_win_darkmode_systemcolor( int color_id )
{

	COLORREF ret;

	if ( n_win_darkmode_onoff )
	{

		if ( color_id == COLOR_WINDOW        ) { ret = n_win_darkmode_bg ; } else
		if ( color_id == COLOR_WINDOWTEXT    ) { ret = n_win_darkmode_fg ; } else
		if ( color_id == COLOR_HIGHLIGHT     ) { ret = RGB( 200,200,200 ); } else
		if ( color_id == COLOR_HIGHLIGHTTEXT ) { ret = RGB( 255,255,255 ); } else
		if ( color_id == COLOR_BTNFACE       ) { ret = n_win_darkmode_bg ; } else
		if ( color_id == COLOR_BTNSHADOW     ) { ret = RGB( 111,111,111 ); } else
		if ( color_id == COLOR_GRAYTEXT      ) { ret = RGB( 200,200,200 ); } else
		if ( color_id == COLOR_BTNTEXT       ) { ret = n_win_darkmode_fg ; } else
		if ( color_id == COLOR_BTNHIGHLIGHT  ) { ret = RGB( 111,111,111 ); } else
		if ( color_id == COLOR_3DLIGHT       ) { ret = RGB( 222,222,222 ); } else
		if ( color_id == COLOR_3DDKSHADOW    ) { ret = RGB(  50, 50, 50 ); } else
		if ( color_id == COLOR_INFOBK        ) { ret = RGB(  50, 50, 50 ); } else
		if ( color_id == COLOR_INFOTEXT      ) { ret = n_win_darkmode_fg ; } else
		{ ret = n_bmp_alpha_invisible_pixel( n_bmp_argb2colorref( n_gdi_systemcolor( color_id ) ) ); }

	} else {

		ret = n_bmp_alpha_invisible_pixel( n_bmp_argb2colorref( n_gdi_systemcolor( color_id ) ) );

	}


	return ret;
}

COLORREF
n_win_darkmode_systemcolor_ui( int color_id )
{

	n_posix_bool p_ui = n_gdi_color_ui;
	n_gdi_color_ui = n_posix_true;

	COLORREF ret = n_win_darkmode_systemcolor( color_id );

	n_gdi_color_ui = p_ui;


	return ret;
}

u32
n_win_darkmode_systemcolor_colorref2argb( int color_id )
{

	COLORREF color = n_win_darkmode_systemcolor( color_id );
	u32      tmp   = n_gdi_colorref2argb( NULL, color );
	u32      ret   = n_bmp_alpha_visible_pixel( tmp );


	return ret;
}

u32
n_win_darkmode_systemcolor_colorref2argb_ui( int color_id )
{

	n_posix_bool p_ui = n_gdi_color_ui;
	n_gdi_color_ui = n_posix_true;

	COLORREF ret = n_win_darkmode_systemcolor_colorref2argb( color_id );

	n_gdi_color_ui = p_ui;


	return ret;
}

void
n_win_darkmode_bmp_flush_reverse( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	while( 1 )
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		color = n_bmp_grayscale_pixel( color );

		int a =       n_bmp_a( color );
		int r = 255 - n_bmp_r( color );
		int g = 255 - n_bmp_g( color );
		int b = 255 - n_bmp_b( color );

		N_BMP_PTR( bmp )[ i ] = n_bmp_argb( a,r,g,b );

		i++;
		if ( i >= c ) { break; }
	}


	return;
}




#endif // _H_NONNON_WIN32_WIN_DARKMODE

