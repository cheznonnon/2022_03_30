// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_combo_zero();
//	n_win_combo_init();
//
//	[ WM_CLOSE ]
//
//	n_win_combo_exit();
//
//	[ WndProc() ]
//
//	n_win_combo_proc()
//
//	[ Add Items ]
//
//	n_txt_set( &combo.txt, index, string )
//
//	[ Selection ]
//
//	n_win_combo_selection_get()/set()
//
//	[ Size ]
//
//	n_win_combo_move()
//
//	+ height will be auto-calculated 
//	+ a parameter "sy" will be count in popup


// [!] : win/control.c uses n_win_combobox_* name space




#ifndef _H_NONNON_WIN32_WIN_COMBOBOX
#define _H_NONNON_WIN32_WIN_COMBOBOX




#include "./win.c"

#include "./win_inputpopup.c"
#include "./win_popup.c"
#include "./win_smallbutton_direct.c"
#include "./win_txtbox.c"




static u8 n_win_smallbutton_arrow_modern[] = {

	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255, 50,255,255,255,255,255,255, 50,255,255,255,255,
	255,255,255,255, 50, 50,255,255,255,255, 50, 50,255,255,255,255,
	255,255,255,255, 50, 50, 50,255,255, 50, 50, 50,255,255,255,255,
	255,255,255,255,255, 50, 50, 50, 50, 50, 50,255,255,255,255,255,
	255,255,255,255,255,255, 50, 50, 50, 50,255,255,255,255,255,255,
	255,255,255,255,255,255,255, 50, 50,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,

};

static u8 n_win_smallbutton_arrow[] = {

	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50,255,255,255,
	255,255,255,255, 50, 50, 50, 50, 50, 50, 50, 50,255,255,255,255,
	255,255,255,255,255, 50, 50, 50, 50, 50, 50,255,255,255,255,255,
	255,255,255,255,255,255, 50, 50, 50, 50,255,255,255,255,255,255,
	255,255,255,255,255,255,255, 50, 50,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,
	255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,

};

u8*
n_win_smallbutton_arrow_get( void )
{

	u8 *ret;


	if ( n_win_fluent_ui_onoff )
	{
		ret = n_win_smallbutton_arrow_modern;
	} else {
		ret = n_win_smallbutton_arrow;
	}


	return ret;
}




#define N_WIN_COMBO_MODE_RECTANGLE ( 0 )
#define N_WIN_COMBO_MODE_ROUND_SYS ( 1 )
#define N_WIN_COMBO_MODE_ROUND_ORG ( 2 )




typedef struct {

	int                      mode;

	n_win_txtbox             input;
	n_win_smallbutton_direct arrow;

	n_txt                    txt;

	n_type_gfx               popup_sx;
	n_type_gfx               popup_sy;
	n_type_int               count_sy;

	n_type_int               selection_index;

	n_posix_bool             is_hovered;

	UINT                     press_timer_id;

	UINT                     slide_timer_id;
	double                   slide_timer_step;
	double                   slide_timer_sy;
	u32                      slide_timer_tick;
	u32                      slide_timer_unit;

	UINT                     wparam_selection_changed;

} n_win_combo;




static n_win_combo *n_win_combo_target = NULL;
static HWND         n_win_combo_hpopup = NULL;
static n_posix_bool n_win_combo_silent = n_posix_false;




#define n_win_combo_zero( p ) n_memory_zero( p, sizeof( n_win_combo ) )

void
n_win_combo_on_settingchange( n_win_combo *p )
{

	n_win_txtbox_on_settingchange( &p->input );

	p->input.txt.readonly = n_posix_true;
	n_win_txtbox_grayed( &p->input, n_posix_true );


	n_win_smallbutton_direct_exit( &p->arrow );

	HWND hwnd_draw  = p->arrow.hwnd_draw;
	HWND hwnd_timer = p->arrow.hwnd_timer;
	HWND hwnd_msg   = p->arrow.hwnd_msg;
	int  id         = p->arrow.id;

	n_win_smallbutton_direct_init_by_data
	(
		&p->arrow,
		hwnd_draw,
		hwnd_timer,
		hwnd_msg,
		id,
		n_win_smallbutton_arrow_get()
	);

	p->arrow.show_onoff = n_posix_true;

	if ( n_win_style_is_classic() )
	{
		//
	} else {
		p->arrow.combine_onoff = n_posix_true;
	}


	return;
}

void
n_win_combo_init( n_win_combo *p, HWND hwnd_parent )
{

	n_win_combo_zero( p );


	{
		int style = 0;

		style |= N_WIN_TXTBOX_STYLE_CMB_BOX;

		if ( n_win_style_is_classic() )
		{
			style |= N_WIN_TXTBOX_STYLE_FLATBDR;
		}

		int option = 0;

		//option |= N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE;
		option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
		option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;
		option |= N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT;

		if ( n_win_style_is_classic() )
		{
			//
		} else
		if ( n_win_fluent_ui_onoff )
		{
			//
		} else {
			option |= N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
		}

		n_win_txtbox_init( &p->input, hwnd_parent, style, option );
	}

	p->input.txt.readonly = n_posix_true;
	n_win_txtbox_grayed( &p->input, n_posix_true );

//n_win_txtbox_line_set( &p->input, 0, n_posix_literal( "Test Test Test" ) );


	n_win_smallbutton_direct_init_by_data
	(
		&p->arrow,
		p->input.hwnd,
		hwnd_parent,
		hwnd_parent,
		1024,
		n_win_smallbutton_arrow_get()
	);

	p->arrow.show_onoff = n_posix_true;

	if ( n_win_style_is_classic() )
	{
		//
	} else {
		p->arrow.combine_onoff = n_posix_true;
	}


	n_txt_new( &p->txt );


	p->is_hovered = n_posix_false;


	p->selection_index = -1;


	p->slide_timer_id           = n_win_timer_id_get();
	p->wparam_selection_changed = n_win_timer_id_get();
	//p->press_timer_id           = n_win_timer_id_get();


	return;
}

void
n_win_combo_exit( n_win_combo *p )
{

	n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );

	n_win_smallbutton_direct_exit( &p->arrow );

	n_win_txtbox_exit( &p->input );

	n_win_property_exit_literal( GetParent( p->input.hwnd ), "Nonnon.Win32.Combobox.Lock" );

	n_txt_free( &p->txt );


	n_win_combo_zero( p );


	return;
}

void
n_win_combo_move( n_win_combo *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	ShowWindow( p->input.hwnd, SW_HIDE );


	n_type_gfx ctl; n_win_stdsize( p->input.hwnd, &ctl, NULL, NULL );

	n_win_move( p->input.hwnd, x,y,sx,ctl, redraw );

	n_win_size_client( p->input.hwnd, &p->popup_sx, NULL );
	p->count_sy = sy;


	n_win_txtbox_smallbutton_direct_embed( &p->input, &p->arrow, 0 );

	n_win_smallbutton_direct_bitmap_init( &p->arrow );


	ShowWindow( p->input.hwnd, SW_NORMAL );


	return;
}

n_posix_char*
n_win_combo_selection_get( n_win_combo *p )
{
	return n_txt_get( &p->txt, p->selection_index );
}

void
n_win_combo_selection_set( n_win_combo *p, n_type_int index )
{

	p->selection_index = index;

	if ( p->selection_index == -1 )
	{
		n_win_txtbox_line_set( &p->input, 0, N_STRING_EMPTY );
	} else {
		n_win_txtbox_line_set( &p->input, 0, n_txt_get( &p->txt, index ) );
	}

	n_win_txtbox_refresh( &p->input, N_WIN_TXTBOX_COMBOBOX );


	return;
}

#define n_win_combo_selection_set_by_string_literal( p, s ) n_win_combo_selection_set_by_string( p, n_posix_literal( s ) )

void
n_win_combo_selection_set_by_string( n_win_combo *p, const n_posix_char *str )
{

	n_type_int i = 0;
	while( 1 )
	{

		n_posix_char *line = p->txt.line[ i ];

		if ( n_string_is_same( line, str ) )
		{
			p->selection_index = i;
			break;
		}

		i++;
		if ( i >= p->txt.sy )
		{
			p->selection_index = -1;
			break;
		}
	}

	n_win_combo_selection_set( p, p->selection_index );


	return;
}

HWND
n_win_combo_hwnd( n_win_combo *p )
{
	return p->input.hwnd;
}

// internal
void
n_win_combo_automove( n_win_combo *p, n_win_txtbox *txtbox, HWND hpopup, HWND target )
{

	// [!] : don't use GetClientRect() : border is needed


	n_type_gfx x,y,sy; n_win_location_relative( NULL, target, &x, &y, NULL, &sy );

	y += sy;


	n_win_txtbox_metrics_canvas( txtbox );

	p->popup_sy = ( txtbox->border_pxl_sy * 1 ) + ( txtbox->pad_pxl_sy * 2 ) + ( txtbox->cell_pxl_sy * (n_type_gfx) p->count_sy );
//n_posix_debug_literal( " %d ", sy );
//n_posix_debug_literal( " %d %d %d ", txtbox->border_pxl_sy, txtbox->pad_pxl_sy, txtbox->cell_pxl_sy );

	n_type_gfx tsx = p->popup_sx;
	n_type_gfx tsy = p->popup_sy;

	if ( p->mode == N_WIN_COMBO_MODE_ROUND_ORG )
	{
		tsx += txtbox->shadow_l + txtbox->shadow_r;
		tsy += txtbox->shadow_u + txtbox->shadow_d;

		x -= txtbox->shadow_l;
	}

	SetWindowPos( hpopup, NULL, x,y,tsx,tsy, SWP_NOACTIVATE | SWP_DRAWFRAME );

	n_win_txtbox_move_simple( txtbox, 0,0,tsx,tsy, n_posix_true );


	return;
}

// internal
void
n_win_combo_slide( n_win_combo *p, n_win_txtbox *txtbox, HWND hpopup )
{

	p->slide_timer_sy = n_posix_max_double( p->slide_timer_sy, (double) txtbox->cell_pxl_sy );

	n_type_gfx sx = p->popup_sx;
	n_type_gfx sy = p->popup_sy;

	sx += txtbox->shadow_l + txtbox->shadow_r;
	sy += txtbox->shadow_u + txtbox->shadow_d;


	p->slide_timer_sy += p->slide_timer_step;
//n_posix_sleep( 500 );

	if ( p->slide_timer_sy >= sy )
	{

		txtbox->mouse_input_stop_onoff = n_posix_false;


		txtbox->combo_popup_slide_onoff = n_posix_false;


		n_win_move_simple( txtbox->hwnd, 0,0,sx,sy, n_posix_false );
		n_win_txtbox_draw( txtbox, N_WIN_TXTBOX_COMBOBOX );

		SetWindowPos( hpopup, NULL, 0,0,sx,sy, SWP_NOMOVE );


		n_win_timer_exit( hpopup, p->slide_timer_id );


		n_bmp_free( &txtbox->bmp_linebuf );

	} else {

		sy = (n_type_gfx) p->slide_timer_sy;

		n_win_move_simple( txtbox->hwnd, 0,0,sx,sy, n_posix_false );
		n_win_txtbox_draw( txtbox, N_WIN_TXTBOX_COMBOBOX );

		SetWindowPos( hpopup, NULL, 0,0,sx,sy, SWP_NOMOVE );

	}

//n_win_hwndprintf_literal( GetParent( hpopup ), " %g ", p->slide_timer_sy );


	return;
}

// internal
BOOL CALLBACK
n_win_combo_EnumChildProc( HWND hwnd, LPARAM lparam )
{

	// [Needed] : WinXP or earlier

	n_win_refresh( hwnd, n_posix_false );


	return TRUE;
}

LRESULT CALLBACK
n_win_combo_popup_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	n_win_combo *p = n_win_combo_target;
	if ( p == NULL ) { return DefWindowProc( hwnd, msg, wparam, lparam ); }


	static n_win_txtbox txtbox;


	switch( msg ) {


	case WM_TIMER :

		if ( wparam == p->slide_timer_id )
		{
			n_win_combo_slide( p, &txtbox, hwnd );

			ShowWindowAsync( hwnd, SW_NORMAL );
		}

	break;


	case WM_CREATE :

		// Global

		p->mode = N_WIN_COMBO_MODE_RECTANGLE;
		//p->mode = N_WIN_COMBO_MODE_ROUND_SYS;
		//p->mode = N_WIN_COMBO_MODE_ROUND_ORG;

		if ( n_win_fluent_ui_onoff )
		{
			p->mode = N_WIN_COMBO_MODE_ROUND_ORG;
		}


		// Window

		n_win_init_literal( hwnd, "", "", "" );

		n_win_topmost( hwnd, n_posix_true );


		// Style

		n_win_style_new( hwnd, WS_POPUP );
		//n_win_style_add( hwnd, WS_BORDER );


		{

			n_win_txtbox_zero( &txtbox );


			int style = 0;

			style |= N_WIN_TXTBOX_STYLE_LISTBOX;
			style |= N_WIN_TXTBOX_STYLE_STRIPED;
			style |= N_WIN_TXTBOX_STYLE_LINEBDR;
			style |= N_WIN_TXTBOX_STYLE_NO_PDNG;

//n_posix_debug_literal( " %d %d ", sy, txtbox.txt.sy );
			if ( p->count_sy < p->txt.sy )
			{
				style |= N_WIN_TXTBOX_STYLE_VSCROLL;
			} else
			if ( p->count_sy > p->txt.sy )
			{
				p->count_sy = p->txt.sy;
			}


			int option = 0;

			option |= N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE;
			option |= N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL;
			option |= N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM;
			option |= N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE;
			option |= N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY;

			if ( p->mode == N_WIN_COMBO_MODE_ROUND_ORG )
			{
				style  |= N_WIN_TXTBOX_STYLE_CMB_POP;
				option |= N_WIN_TXTBOX_OPTION_COMBOBOX_SHADOW;
			}

			if ( n_win_fluent_ui_onoff )
			{
				if ( p->mode != N_WIN_COMBO_MODE_RECTANGLE )
				{
					option |= N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC;
				}
			} else
			if ( n_win_style_is_classic() )
			{
				//
			} else {
				// [x] : buggy : not supported
				//option |= N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON;
			}

			n_win_txtbox_init( &txtbox, hwnd, style, option );


			n_type_gfx ctl,m; n_win_stdsize( hwnd, &ctl, NULL, &m );
			txtbox.virtual_padding_pxl_sx = m * 2;

			n_type_gfx border = p->input.border_pxl_sy;
			n_win_txtbox_metrics_vertical_spacing( &txtbox, ctl - ( m * 2 ) - ( border * 2 ) );


			n_txt_copy( &p->txt, &txtbox.txt );

		}


		// Size

		n_win_combo_automove( p, &txtbox, hwnd, p->input.hwnd );

		if (
			(
				( n_win_fluent_ui_onoff )
				&&
				( txtbox.style_option & N_WIN_TXTBOX_OPTION_LISTBOX_ROUNDRC )
			)
			||
			( txtbox.style_option & N_WIN_TXTBOX_OPTION_VISUAL_STYLE_ON )
		)
		{
			if ( p->mode == N_WIN_COMBO_MODE_RECTANGLE )
			{
				//
			} else
			if ( p->mode == N_WIN_COMBO_MODE_ROUND_SYS )
			{
				n_type_gfx csx,csy; n_win_size( hwnd, &csx,&csy );

				n_type_gfx round = n_win_fluent_ui_round_param( hwnd );
				n_win_fluent_ui_roundrect_region( hwnd, csx, csy, round );

				txtbox.vscr.color_edge_ur = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );
				txtbox.vscr.color_edge_dr = txtbox.vscr.color_edge_ur;
			} else
			if ( p->mode == N_WIN_COMBO_MODE_ROUND_ORG )
			{
				txtbox.vscr.bmp_parent = &txtbox.bmp;
			}
		}


		// Display

		n_win_inputpopup_close();

		n_win_txtbox_line_select( &txtbox,              p->selection_index );
		n_win_txtbox_line_scroll( &txtbox, (n_type_gfx) p->selection_index );
		n_win_txtbox_autofocus  ( &txtbox,                   n_posix_false );


		{

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETCOMBOBOXANIMATION, 0, &onoff, 0 );

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			if ( onoff )
			{

				// [x] : Fluent UI : desktop screenshot will be garbage

				if ( p->mode == N_WIN_COMBO_MODE_ROUND_ORG )
				{

					txtbox.           bitblt_stop = n_posix_true;
					txtbox.line_buffer_make_onoff = n_posix_true;

					n_win_txtbox_draw( &txtbox, N_WIN_TXTBOX_COMBOBOX );
//n_bmp_save_literal( &txtbox.bmp_linebuf, "ret2.bmp" );

					txtbox.           bitblt_stop = n_posix_false;
					txtbox.line_buffer_make_onoff = n_posix_false;


					txtbox. mouse_input_stop_onoff = n_posix_true;
					txtbox.combo_popup_slide_onoff = n_posix_true;


					n_type_gfx csy = txtbox.canvas_pxl_sy + 1;
					n_type_gfx tsy = (n_type_gfx) txtbox.txt.sy * txtbox.cell_pxl_sy;

					txtbox.combo_popup_slide_no_scroll = ( csy == tsy );
					txtbox.combo_popup_slide_parameter = csy;
					txtbox.combo_popup_slide_index     = ( (n_type_gfx) txtbox.scroll_pxl_tabbed_y / txtbox.cell_pxl_sy ) + ( csy / txtbox.cell_pxl_sy );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d %d ", csy, tsy );
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %d ", txtbox.combo_popup_slide_index );


					// [Needed] : Win10 : to improve performance

					txtbox.dibsection_stop_onoff = n_posix_true;


					// [!] : Win32 minimal : 10 msec.

					n_type_gfx slide_msec = 10;

					p->slide_timer_sy   = 0;
					p->slide_timer_unit = N_BMP_FADE_MSEC;
					p->slide_timer_step = (double) p->popup_sy / p->slide_timer_unit * slide_msec;
					p->slide_timer_tick = n_posix_tickcount();
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), "%f", p->slide_timer_step );


					n_win_timer_init( hwnd, p->slide_timer_id, slide_msec );

					ShowWindow( hwnd, SW_HIDE );

				} else {

					n_win_style_dropshadow_onoff( hwnd, n_posix_true );


					n_win_scrollbar_printclient             = n_posix_true;
					n_win_txtbox_printclient                = n_posix_true;
					n_win_scrollbar_draw_always_printclient = n_posix_true;

					int aw = n_AW_ACTIVATE | n_AW_SLIDE | n_AW_VER_POSITIVE;

/*
					// [x] : Win2000 : n_AW_SLIDE : not working : when using region

					if ( n_win_fluent_ui_onoff )
					{
						if ( n_posix_false == n_sysinfo_version_xp_or_later() )
						{
							aw = n_AW_BLEND | n_AW_VER_POSITIVE;
						}
					}
*/
					n_posix_bool ret = n_win_animatewindow( hwnd, 0, aw );
					if ( ret ) { ShowWindow( hwnd, SW_NORMAL ); }

					n_win_scrollbar_printclient             = n_posix_false;
					n_win_txtbox_printclient                = n_posix_false;
					n_win_scrollbar_draw_always_printclient = n_posix_false;

				}

			} else {

				n_win_style_dropshadow_onoff( hwnd, n_posix_true );

				ShowWindow( hwnd, SW_NORMAL );

			}

#else  // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			ShowWindow( hwnd, SW_NORMAL );

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == txtbox.hwnd )
		{
			if ( wparam == WM_LBUTTONDOWN )
			{

				p->selection_index = txtbox.select_cch_y;

				n_posix_char *str = n_txt_get( &p->txt, p->selection_index );
				n_win_txtbox_selection_mod( &p->input, str );
				n_win_txtbox_refresh( &p->input, N_WIN_TXTBOX_COMBOBOX );

				n_win_message_send( GetParent( p->input.hwnd ), WM_COMMAND, p->wparam_selection_changed, p->input.hwnd );

				n_win_smallbutton_direct_hover( &p->arrow, n_posix_false, n_posix_true );
				n_win_smallbutton_direct_bitmap_draw( &p->arrow );

				n_win_message_post( hwnd, WM_CLOSE, 0, 0 );

			} else
			if ( wparam == WM_MOUSEMOVE )
			{
				//p->selection_index = txtbox.select_cch_y;

				//n_posix_char *str = n_txt_get( &p->txt, p->selection_index );
				//n_win_txtbox_selection_mod( &p->input, str );
				///n_win_txtbox_refresh( &p->input, N_WIN_TXTBOX_COMBOBOX );
			}
		}

	break;


	case WM_MOUSEHOVER :

		SetFocus( txtbox.hwnd );

	break;

	case WM_MOUSEMOVE :

		n_win_on_mousemove( hwnd );

	break;

/*
	case WM_LBUTTONDBLCLK :
	case WM_LBUTTONDOWN   :

		SetCapture( hwnd );

	break;

	case WM_LBUTTONUP :

		ReleaseCapture();

	break;
*/

	case WM_KILLFOCUS :
//n_win_txtbox_debug_count( &txtbox );

		// [!] : never comes when app lost focus

	break;

	case WM_ACTIVATE :
//n_win_txtbox_debug_count( &txtbox );

		if ( wparam == WA_INACTIVE )
		{
//n_win_message_send( (HWND) lparam, WM_CLOSE, 0,0 );

			if ( (HWND) lparam == NULL )
			{
				n_win_message_send( hwnd, WM_CLOSE, 0, 0 );
			}
		}
/*
if ( p != NULL )
{
	n_win_hwndprintf_literal
	(
		n_win_hwnd_toplevel( hwnd ),
		" %x %x : %x %x %x : %x %x %x %x",
		lparam,
		GetParent( hwnd ),

		hwnd,
		n_win_hwnd_window( hwnd ),
		n_win_combo_hpopup,

		n_win_hwnd_toplevel( hwnd ),
		txtbox.hwnd,
		p->input.hwnd,
		GetFocus()

	);
}
*/
	break;


	case WM_CLOSE :

		if ( n_win_combo_silent == n_posix_false )
		{

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETMENUFADE, 0, &onoff, 0 );

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			if ( onoff )
			{
				n_win_scrollbar_printclient             = n_posix_true;
				n_win_txtbox_printclient                = n_posix_true;
				n_win_scrollbar_draw_always_printclient = n_posix_true;

				int aw = n_AW_HIDE | n_AW_BLEND | n_AW_VER_NEGATIVE;
				n_win_animatewindow( hwnd, 0, aw );

				n_win_scrollbar_printclient             = n_posix_false;
				n_win_txtbox_printclient                = n_posix_false;
				n_win_scrollbar_draw_always_printclient = n_posix_false;
			}

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

		} else {

			n_win_combo_silent = n_posix_false;

		}


		n_win_txtbox_exit( &txtbox );


		p->input.smallbutton_once = n_posix_true;
		n_win_txtbox_on_focus( &p->input, n_posix_false );


		// [Needed] : WinXP or earlier : see Nyaurism

		EnumChildWindows( GetParent( hwnd ), n_win_combo_EnumChildProc, (LPARAM) 0 );


		// [Needed] : non-DWM
		//
		//	you need to implement WM_SIZE with redraw n_posix_true
		//	you need to implement WM_PAINT

		n_win_message_send( GetParent( hwnd ), WM_SIZE , 0,0 );
		n_win_message_send( GetParent( hwnd ), WM_PAINT, 0,0 );


		n_win_combo_target = NULL;
		n_win_combo_hpopup = NULL;

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	} // switch


	{
		int ret = n_win_txtbox_proc( hwnd, msg, wparam, lparam, &txtbox );
		if ( ret ) { return ret; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_win_combo_popup_patch( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam, HWND hpopup )
{

	// [!] : suppress gray-out when "hpopup" is active

	switch( msg ) {

	case WM_NCACTIVATE :
//n_win_hwndprintf_literal( hwnd, " %x %d %d ", hpopup, (*wparam), IsWindow( hpopup ) );
		if ( (*wparam) == n_posix_false )
		{
			(*wparam) = ( n_win_combo_target != NULL );//IsWindow( hpopup );
		}

	break;

	} // switch


	// [!] : restoring is needed when "hpopup" is closed

	static n_posix_bool onoff = n_posix_false;

	if ( IsWindow( hpopup ) )
	{

	 	onoff = n_posix_true;

	} else
	if ( onoff )
	{

		onoff = n_posix_false;


		//HWND  h       = n_win_cursor2hwnd();
		n_posix_bool restore = n_posix_true;//n_posix_false;

/*
		if (
			( hwnd == h )
			||
			( IsChild(   hwnd, h ) )
			||
			( IsChild( hpopup, h ) )
		)
		{
			restore = n_posix_true;
		}
*/

		n_win_message_send( hwnd, WM_NCACTIVATE, restore, 0 );


		// [!] : Win95 : hangup
		//
		//	don't use SetActiveWindow( hwnd );

		if ( restore ) { SetFocus( hwnd ); }

	}


	return;
}

void
n_win_combo_smallbutton_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_combo *p )
{
//return;

	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( p->arrow.fade_timer == wparam )
		{
//n_posix_debug_literal( " WM_TIMER " );
			n_win_smallbutton_direct_bitmap_init( &p->arrow );
			n_win_smallbutton_direct_bitmap_draw( &p->arrow );

			if ( p->arrow.fade.stop ) { n_win_timer_exit( p->arrow.hwnd_timer, p->arrow.fade_timer ); }

		}

	break;


	case WM_LBUTTONDOWN :
	{

		if ( p->arrow.show_onoff == n_posix_false ) { break; }

		//n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( &p->arrow );
		n_posix_bool onoff = n_win_is_hovered( p->arrow.hwnd_draw );
		if ( onoff )
		{
			n_win_smallbutton_direct_press( &p->arrow, n_posix_true, n_posix_true );
			n_win_smallbutton_direct_bitmap_draw( &p->arrow );
		}

	}
	break;

	case WM_LBUTTONUP :

		if ( p->arrow.show_onoff == n_posix_false ) { break; }

		if ( n_win_is_hovered( p->input.hwnd ) )
		{
//n_win_hwndprintf_literal( hwnd, " n_win_is_hovered() " );

			if ( n_win_inputpopup_txtbox_prv != NULL )
			{
//n_win_hwndprintf_literal( hwnd, " n_win_inputpopup_txtbox " );
				if ( n_win_inputpopup_txtbox_prv->focus_fade_is_running ) { break; }
			}

			if ( n_win_smallbutton_direct_is_pressed( &p->arrow ) )
			{
//n_win_hwndprintf_literal( hwnd, " n_win_smallbutton_direct_is_pressed() " );

				n_win_smallbutton_direct_press( &p->arrow, n_posix_false, n_posix_true );
				n_win_smallbutton_direct_bitmap_draw( &p->arrow );

				if ( n_win_smallbutton_direct_is_hovered( &p->arrow ) )
				{
					n_win_message_post( p->arrow.hwnd_msg, WM_COMMAND, p->arrow.id, p->arrow.hwnd_msg );
				}

				//n_win_timer_init( hwnd, p->press_timer_id, 100 );

				if ( n_win_combo_hpopup == NULL )
				{
					n_win_combo_target = p;
					n_win_gui( p->input.hwnd, N_WIN_GUI_WINDOW, n_win_combo_popup_proc, &n_win_combo_hpopup );
				} else {
					n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
				}

				if ( ( n_win_combo_target != NULL )&&( n_win_combo_target != p ) )
				{
					n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
				}
			}

		} else {

		}

	break;

	case WM_MOUSEMOVE :
	{

		if ( n_win_combo_hpopup != NULL ) { break; }

		if ( p->arrow.show_onoff == n_posix_false ) { break; }

		int p_state = p->arrow.state;

		//n_posix_bool onoff = n_win_smallbutton_direct_is_hovered( &p->arrow );
		n_posix_bool onoff = n_win_is_hovered( p->arrow.hwnd_draw );
		if ( onoff == n_posix_false )
		{
			if ( n_win_smallbutton_direct_is_pressed( &p->arrow ) )
			{
				n_win_smallbutton_direct_press( &p->arrow, n_posix_false, n_posix_true );
			}
		}

		if ( ( onoff )&&( p->arrow.combine_onoff ) )
		{

			n_win_smallbutton_direct_hover_main( &p->arrow, onoff, n_posix_false, n_posix_false );

		} else {

			n_win_smallbutton_direct_hover( &p->arrow, onoff, n_posix_true );

			if ( p_state != p->arrow.state )
			{
				if ( p->input.style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
				{
					//
				} else {
					//n_win_smallbutton_direct_bitmap_draw( &p->arrow );
				}
			}

		}

	}
	break;

	} // switch


	return;
}

LRESULT
n_win_combo_proc( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam, n_win_combo *p )
{

	switch( msg ) {


	case WM_MOVE :

		if ( n_win_combo_hpopup != NULL )
		{
			if ( p->mode == N_WIN_COMBO_MODE_ROUND_ORG )
			{
				n_win_combo_silent = n_posix_true;
				n_win_message_post( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
				break;
			}

			n_type_gfx x,y,sx,sy; n_win_location_relative( NULL, n_win_combo_target->input.hwnd, &x, &y, NULL, &sy );
			y += sy;

			n_win_size( n_win_combo_hpopup, &sx, &sy );

			SetWindowPos( n_win_combo_hpopup, NULL, x,y,sx,sy, SWP_NOACTIVATE | SWP_DRAWFRAME );
		}

	break;

	//case WM_NCLBUTTONDOWN :
	case WM_NCMBUTTONDOWN :
	case WM_NCRBUTTONDOWN :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :

		if (
			( n_win_combo_target != NULL )
			&&
			( n_posix_false == n_win_is_hovered( n_win_combo_target->input.hwnd ) )
		)
		{
			n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
		}

	break;

	case WM_LBUTTONUP :
	case WM_MBUTTONUP :
	case WM_RBUTTONUP :

	break;


	case WM_MOUSEMOVE :
//n_win_hwndprintf_literal( hwnd, " %x ", n_win_cursor2hwnd_relative( hwnd ) );

		// [x] : conflict with smallbutton

		if (
			( n_win_combo_target == p )
			||
			( n_win_is_hovered( n_win_combo_hpopup ) )
			||
			( n_win_is_hovered( p->input.hwnd ) )
		)
		{
			if ( p->input.selected_border_onoff == n_posix_false )
			{
				n_win_txtbox_on_focus( &p->input, n_posix_true );
			}
		} else {
			if ( p->input.selected_border_onoff )
			{
				n_win_txtbox_on_focus( &p->input, n_posix_false );
			}
		}

	break;


	case WM_TIMER :
/*
		if ( (*wparam) == p->press_timer_id )
		{
			n_win_timer_exit( hwnd, p->press_timer_id );

			if ( n_win_combo_hpopup == NULL )
			{
				n_win_combo_target = p;
				n_win_gui( p->input.hwnd, N_WIN_GUI_WINDOW, n_win_combo_popup_proc, &n_win_combo_hpopup );
			} else {
				n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
			}

			if ( ( n_win_combo_target != NULL )&&( n_win_combo_target != p ) )
			{
				n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
			}
		}
*/
	break;


	case WM_COMMAND :

		if ( (HWND) (*lparam) == p->input.hwnd )
		{
//n_posix_debug_literal( "%d", wparam );

			// [!] : when a combo item is selected

			//n_win_txtbox_refresh( &p->input, 0 );

			//n_win_txtbox_fade_go( &p->input, &p->input.aero_combo_fade );
			//n_win_timer_init( p->input.hwnd, p->input.aero_combo_timer, 33 );

		} else
		if ( (HWND) (*lparam) == p->arrow.hwnd_msg )
		{
/*
			if ( (*wparam) == p->arrow.id )
			{
				n_win_timer_init( hwnd, p->press_timer_id, 100 );
			}
*/
		}

	break;


	case WM_KILLFOCUS :
//n_win_hwndprintf_literal( hwnd, " %x %x %x ", wparam, hwnd, n_win_combo_hpopup );
//n_win_txtbox_debug_count( &p->input );
/*
n_win_hwndprintf_literal
(
	n_win_hwnd_toplevel( hwnd ),
	" %x %x %x %x %x ",
	wparam,
	hwnd,
	n_win_combo_hpopup,
	p->input.hwnd,
	GetFocus()

);
*/
		if ( ( NULL == GetFocus() )&&( n_win_combo_hpopup != NULL ) )
		{
			n_win_message_send( n_win_combo_hpopup, WM_CLOSE, 0, 0 );
		}

	break;


	} // switch


	n_win_combo_smallbutton_proc( hwnd, msg, *wparam, *lparam, p );


	{
		int ret = n_win_txtbox_proc( hwnd, msg, *wparam, *lparam, &p->input );
		if ( ret ) { return ret; }
	}


	n_win_combo_popup_patch( hwnd, msg, wparam, lparam, n_win_combo_hpopup );


	return 0;
}


#endif // _H_NONNON_WIN32_WIN_COMBOBOX


