// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "", &hgui );
//
//	[ WndProc() ]
//
//	n_win_separator_proc()
//
//	"ps" : <wingdi.h> : PS_SOLID, PS_DOT, PS_DASH...




#ifndef _H_NONNON_WIN32_WIN_SEPARATOR
#define _H_NONNON_WIN32_WIN_SEPARATOR




#include "./gdi/doublebuffer.c"
#include "./win.c"




// internal
void
n_win_separator_line( HDC hdc, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, DWORD color, int ps )
{

	HGDIOBJ hp = SelectObject( hdc, CreatePen( ps, 1, color ) );

	sx += x;
	sy += y;
	MoveToEx( hdc, x,y, NULL ); LineTo( hdc, sx,sy );

	DeleteObject( SelectObject( hdc, hp ) );


	return;
}

// internal
void
n_win_separator_text( HDC hdc, n_type_gfx x, n_type_gfx y, COLORREF color_bg, COLORREF color_fg, n_posix_char *text, n_type_int text_len )
{

	SetBkColor  ( hdc, color_bg );
	SetTextColor( hdc, color_fg );

	TextOut( hdc, x,y, text, (int) text_len );


	return;
}

// internal
void
n_win_separator_draw( HWND hgui, HDC hdc_override, RECT *rect, int ps )
{

	const n_type_gfx m = 4;


	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	HDC hdc;
hdc_override = NULL;
	if ( hdc_override == NULL )
	{
		hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );
	} else {
		hdc = hdc_override;
	}


	// Draw

	{

		COLORREF color_bg     = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE    );
		COLORREF color_shadow = n_win_darkmode_systemcolor_ui( COLOR_BTNSHADOW  );
		COLORREF color_hilite = n_win_darkmode_systemcolor_ui( COLOR_BTNHILIGHT );
		COLORREF color_text   = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT    );


		// Background

		n_win_box( hgui, hdc, rect, color_bg );


		// Text

		int           text_cch = n_win_text_len( hgui );
		n_posix_char *text_str = n_string_new( text_cch ); n_win_text_get( hgui, text_str, text_cch + 1 );
		SIZE          size; GetTextExtentPoint32( hdc, text_str, text_cch, &size );


		n_type_gfx tx = x;
		n_type_gfx ty = ( sy - size.cy ) / 2;

		if ( IsWindowEnabled( hgui ) )
		{
			n_win_separator_text( hdc, 0+tx,0+ty, color_bg, color_text,   text_str, text_cch );
		} else {
			n_win_separator_text( hdc, 1+tx,1+ty, color_bg, color_hilite, text_str, text_cch );
			n_win_separator_text( hdc, 0+tx,0+ty, color_bg, color_shadow, text_str, text_cch );
		}


		// Etched Horizontal Line

		tx = x + size.cx;
		ty = ( sy / 2 );

		if ( text_cch != 0 ) { tx += m; }

		n_win_separator_line( hdc, tx,1+ty, sx,0, color_hilite, ps );
		n_win_separator_line( hdc, tx,0+ty, sx,0, color_shadow, ps );


		n_string_free( text_str );

	}


	if ( hdc_override == NULL )
	{
		if ( n_win_dwm_is_on() ) { n_gdi_doublebuffer_visible( &n_gdi_doublebuffer_instance ); }
		n_gdi_doublebuffer_simple_exit();
	} else {
		//
	}


	return;
}

void
n_win_separator_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui, int ps )
{

	switch( msg ) {


	case WM_SIZE :
	{

		if ( n_posix_false == IsWindow( hgui ) ) { break; }

		n_win_refresh( hgui, n_posix_false );

	}
	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		n_win_separator_draw( hgui, di->hDC, &di->rcItem, ps );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SEPARATOR


/*


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui[ 6 ];


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_SOLID :  Enabled", &hgui[ 0 ] );
		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_DOT   :  Enabled", &hgui[ 1 ] );
		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_DASH  :  Enabled", &hgui[ 2 ] );
		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_SOLID : Disabled", &hgui[ 3 ] );
		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_DOT   : Disabled", &hgui[ 4 ] );
		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "PS_DASH  : Disabled", &hgui[ 5 ] );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		EnableWindow( hgui[ 3 ], n_posix_false );
		EnableWindow( hgui[ 4 ], n_posix_false );
		EnableWindow( hgui[ 5 ], n_posix_false );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		const n_posix_bool redraw = n_posix_true;

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		n_type_gfx sx = w.csx;
		n_type_gfx sy = w.csy / 6;

		n_win_move_simple( hgui[ 0 ], 0,sy*0, sx,sy, redraw );
		n_win_move_simple( hgui[ 1 ], 0,sy*1, sx,sy, redraw );
		n_win_move_simple( hgui[ 2 ], 0,sy*2, sx,sy, redraw );
		n_win_move_simple( hgui[ 3 ], 0,sy*3, sx,sy, redraw );
		n_win_move_simple( hgui[ 4 ], 0,sy*4, sx,sy, redraw );
		n_win_move_simple( hgui[ 5 ], 0,sy*5, sx,sy, redraw );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 0 ], PS_SOLID );
	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 1 ], PS_DOT   );
	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 2 ], PS_DASH  );
	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 3 ], PS_SOLID );
	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 4 ], PS_DOT   );
	n_win_separator_proc( hwnd,msg,wparam,lparam, hgui[ 5 ], PS_DASH  );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/

